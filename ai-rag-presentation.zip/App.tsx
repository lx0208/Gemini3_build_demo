import React, { useState, useEffect, useCallback } from 'react';
import { Layout } from './components/Layout';
import { Logo } from './components/Logo';
import { slides } from './data/slides';
import { SlideType } from './types';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight } from 'lucide-react';

const App: React.FC = () => {
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);

  const nextSlide = useCallback(() => {
    setCurrentSlideIndex((prev) => Math.min(prev + 1, slides.length - 1));
  }, []);

  const prevSlide = useCallback(() => {
    setCurrentSlideIndex((prev) => Math.max(prev - 1, 0));
  }, []);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight' || e.key === 'ArrowDown' || e.key === 'Space') {
        nextSlide();
      } else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
        prevSlide();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [nextSlide, prevSlide]);

  const currentSlide = slides[currentSlideIndex];

  // Render content based on slide type
  const renderSlideContent = () => {
    switch (currentSlide.type) {
      case SlideType.TITLE:
        return (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
              className="text-6xl font-serif-jp font-bold text-slate-800 mb-6 tracking-wide"
            >
              {currentSlide.title}
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4, duration: 0.8 }}
              className="text-2xl text-slate-500 font-light"
            >
              {currentSlide.subtitle}
            </motion.p>
            <motion.div 
               initial={{ width: 0 }}
               animate={{ width: "100px" }}
               transition={{ delay: 0.8, duration: 0.5 }}
               className="h-1 bg-slate-800 mt-12"
            />
          </div>
        );

      case SlideType.SECTION:
        return (
          <div className="flex flex-col items-start justify-center h-full px-24">
             <motion.div
               initial={{ x: -50, opacity: 0 }}
               animate={{ x: 0, opacity: 1 }}
               className="text-indigo-500 font-bold tracking-widest mb-4"
             >
               SECTION
             </motion.div>
             <motion.h1 
               initial={{ x: -20, opacity: 0 }}
               animate={{ x: 0, opacity: 1 }}
               transition={{ delay: 0.2 }}
               className="text-5xl font-serif-jp font-bold text-slate-800 mb-4"
             >
              {currentSlide.title}
            </motion.h1>
             {currentSlide.subtitle && (
               <motion.h2 
                 initial={{ opacity: 0 }}
                 animate={{ opacity: 1 }}
                 transition={{ delay: 0.4 }}
                 className="text-2xl text-slate-500"
               >
                 {currentSlide.subtitle}
               </motion.h2>
             )}
          </div>
        );

      case SlideType.AGENDA:
      case SlideType.CONTENT:
        return (
          <div className="h-full pt-20 px-24 pb-12 flex flex-col">
            {currentSlide.type === SlideType.CONTENT && (
                <div className="mb-8 border-b border-slate-200 pb-2">
                   <h2 className="text-3xl font-bold text-slate-800">{currentSlide.title}</h2>
                </div>
            )}
            {currentSlide.type === SlideType.AGENDA && (
                <div className="mb-12">
                   <h2 className="text-4xl font-serif-jp text-slate-800">{currentSlide.title}</h2>
                </div>
            )}
            <div className="flex-1 relative">
                {currentSlide.content}
            </div>
          </div>
        );

      case SlideType.END:
        return (
          <div className="flex flex-col items-center justify-center h-full text-center bg-slate-800 text-white">
             <Logo className="w-24 h-24 text-white mb-8 opacity-80" />
             <motion.h1 
               initial={{ scale: 0.9, opacity: 0 }}
               animate={{ scale: 1, opacity: 1 }}
               className="text-4xl font-serif-jp font-bold mb-4"
             >
               {currentSlide.title}
             </motion.h1>
             <p className="text-xl text-slate-400">{currentSlide.subtitle}</p>
          </div>
        );
      
      default:
        return null;
    }
  };

  return (
    <Layout 
      currentSlideIndex={currentSlideIndex} 
      totalSlides={slides.length}
      sectionTitle={currentSlide.sectionTitle}
    >
      <AnimatePresence mode="wait">
        <motion.div
          key={currentSlideIndex}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.4 }}
          className="w-full h-full"
        >
          {renderSlideContent()}
        </motion.div>
      </AnimatePresence>

      {/* Navigation Controls (Visible on hover or mobile) */}
      <div className="absolute inset-y-0 left-0 w-24 flex items-center justify-start pl-4 opacity-0 hover:opacity-100 transition-opacity z-30">
        <button onClick={prevSlide} disabled={currentSlideIndex === 0} className="p-2 rounded-full bg-black/5 hover:bg-black/10 disabled:opacity-0">
          <ChevronLeft className="w-8 h-8 text-slate-600" />
        </button>
      </div>
      <div className="absolute inset-y-0 right-0 w-24 flex items-center justify-end pr-4 opacity-0 hover:opacity-100 transition-opacity z-30">
        <button onClick={nextSlide} disabled={currentSlideIndex === slides.length - 1} className="p-2 rounded-full bg-black/5 hover:bg-black/10 disabled:opacity-0">
          <ChevronRight className="w-8 h-8 text-slate-600" />
        </button>
      </div>

    </Layout>
  );
};

export default App;