import React from 'react';
import { Database, FileText, ArrowRight, Server, FileCode, Layers, User, Search, List, MessageSquare, FileOutput, ArrowDown, ArrowLeft } from 'lucide-react';
import { motion } from 'framer-motion';

// --- Reusable Components for Flowcharts ---

const FlowCard = ({ 
  icon: Icon, 
  title, 
  desc, 
  step, 
  colorClass = "border-slate-300", 
  iconBgClass = "bg-slate-50",
  delay = 0 
}: { 
  icon: any, 
  title: string, 
  desc: string, 
  step: number, 
  colorClass?: string, 
  iconBgClass?: string,
  delay?: number
}) => (
  <motion.div 
    initial={{ opacity: 0, y: 10 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ delay, duration: 0.5 }}
    className={`relative flex flex-col items-center p-4 bg-white rounded-xl shadow-sm border-b-4 ${colorClass} w-44 h-36 z-10 justify-between`}
  >
    <div className="absolute -top-3 -left-3 w-7 h-7 rounded-full bg-slate-700 text-white flex items-center justify-center text-xs font-bold shadow-md border-2 border-white">
      {step}
    </div>
    <div className={`mt-1 p-3 rounded-full ${iconBgClass}`}>
      <Icon className="w-6 h-6 text-slate-700" />
    </div>
    <div className="flex flex-col items-center flex-1 justify-center w-full">
      <h3 className="text-sm font-bold text-slate-700 text-center mb-1 leading-tight">{title}</h3>
      <p className="text-[10px] text-slate-500 text-center leading-snug w-full px-1">{desc}</p>
    </div>
  </motion.div>
);

const ConnectorRight = ({ delay = 0 }: { delay?: number }) => (
  <motion.div 
    initial={{ width: 0, opacity: 0 }}
    animate={{ width: "100%", opacity: 1 }}
    transition={{ delay, duration: 0.5 }}
    className="flex-1 h-[2px] bg-slate-300 mx-2 relative top-[-20px]" 
  >
     <div className="absolute right-0 -top-[5px] text-slate-300">
        <ArrowRight className="w-4 h-4" />
     </div>
  </motion.div>
);

const ConnectorLeft = ({ delay = 0 }: { delay?: number }) => (
  <motion.div 
    initial={{ width: 0, opacity: 0 }}
    animate={{ width: "100%", opacity: 1 }}
    transition={{ delay, duration: 0.5 }}
    className="flex-1 h-[2px] bg-slate-300 mx-2 relative top-[-20px]" 
  >
     <div className="absolute left-0 -top-[5px] text-slate-300 rotate-180">
        <ArrowRight className="w-4 h-4" />
     </div>
  </motion.div>
);

// --- Diagrams ---

export const BatchImportFlow = () => {
  return (
    <div className="w-full max-w-4xl mx-auto py-4 flex flex-col gap-8 relative">
      
      {/* Row 1: Left to Right */}
      <div className="flex items-center justify-between relative">
        <FlowCard 
          step={1} 
          icon={Server} 
          title="OCI Object Storage" 
          desc="Bucket (pptx, docx等)" 
          colorClass="border-slate-400"
          delay={0.1}
        />
        <ConnectorRight delay={0.4} />
        <FlowCard 
          step={2} 
          icon={FileCode} 
          title="Text Conversion" 
          desc="Python / LibreOfficeでテキスト化" 
          colorClass="border-slate-400"
          delay={0.2}
        />
        <ConnectorRight delay={0.5} />
        <FlowCard 
          step={3} 
          icon={FileText} 
          title="Document Loaders" 
          desc="LangChainでDocument形式へ" 
          colorClass="border-slate-400"
          delay={0.3}
        />
      </div>

      {/* Vertical Connection (Right side) */}
      <motion.div 
        initial={{ height: 0, opacity: 0 }}
        animate={{ height: "60px", opacity: 1 }}
        transition={{ delay: 0.6, duration: 0.4 }}
        className="absolute right-[5.5rem] top-[8.5rem] w-[2px] bg-slate-300 z-0"
      >
        <div className="absolute bottom-0 -left-[7px] text-slate-300">
          <ArrowDown className="w-4 h-4" />
        </div>
      </motion.div>

      {/* Row 2: Right to Left */}
      <div className="flex items-center justify-between flex-row-reverse relative mt-2">
        {/* Note: In flex-row-reverse, the first child is visually on the right */}
        <FlowCard 
          step={4} 
          icon={Layers} 
          title="Text Splitter" 
          desc="文脈を維持しつつ分割" 
          colorClass="border-indigo-400"
          iconBgClass="bg-indigo-50"
          delay={0.7}
        />
        <ConnectorLeft delay={0.8} />
        <FlowCard 
          step={5} 
          icon={Database} 
          title="Embedding Model" 
          desc="ベクトルデータへ変換" 
          colorClass="border-indigo-400"
          iconBgClass="bg-indigo-50"
          delay={0.9}
        />
        <ConnectorLeft delay={1.0} />
        <FlowCard 
          step={6} 
          icon={Database} 
          title="PostgreSQL" 
          desc="pgvectorでナレッジ保存" 
          colorClass="border-emerald-500"
          iconBgClass="bg-emerald-50"
          delay={1.1}
        />
      </div>

      {/* Background decoration to link the U-turn visually */}
      <div className="absolute top-[8.5rem] right-[5.5rem] w-8 h-8 rounded-tr-xl border-t-2 border-r-2 border-slate-100 opacity-50 pointer-events-none"></div>

    </div>
  );
};

export const ChatResponseFlow = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  return (
    <motion.div 
      variants={containerVariants}
      initial="hidden"
      animate="show"
      className="w-full max-w-5xl mx-auto py-4"
    >
      <div className="grid grid-cols-5 gap-4 items-start relative">
        
        {/* Step 1 */}
        <motion.div variants={itemVariants} className="col-span-1 flex flex-col items-center">
          <div className="bg-slate-800 text-white p-4 rounded-full w-16 h-16 flex items-center justify-center mb-4 shadow-lg z-10">
            <User className="w-8 h-8" />
          </div>
          <div className="text-center">
            <p className="font-bold text-sm">User Question</p>
            <p className="text-xs text-slate-500">質問入力</p>
          </div>
        </motion.div>

        {/* Arrow */}
        <div className="absolute top-8 left-[15%] w-[10%] border-t-2 border-slate-300"></div>

        {/* Step 2 */}
        <motion.div variants={itemVariants} className="col-span-1 flex flex-col items-center">
          <div className="bg-white border border-slate-200 p-4 rounded-lg w-full h-32 flex flex-col items-center justify-center shadow-sm z-10">
            <Search className="w-6 h-6 text-indigo-500 mb-2" />
            <p className="font-bold text-xs text-center">Retrieval</p>
            <p className="text-[10px] text-slate-500 text-center">プロジェクト計画書<br/>(Top 2 Score)</p>
          </div>
        </motion.div>

        {/* Arrow */}
        <div className="absolute top-8 left-[35%] w-[10%] border-t-2 border-slate-300"></div>

        {/* Step 3 */}
        <motion.div variants={itemVariants} className="col-span-1 flex flex-col items-center">
          <div className="bg-white border border-slate-200 p-4 rounded-lg w-full h-32 flex flex-col items-center justify-center shadow-sm z-10">
             <List className="w-6 h-6 text-indigo-500 mb-2" />
             <p className="font-bold text-xs text-center">Logic</p>
             <p className="text-[10px] text-slate-500 text-center">Get Project ID<br/>&rarr; Find All 議事録</p>
          </div>
        </motion.div>

        {/* Arrow */}
        <div className="absolute top-8 left-[55%] w-[10%] border-t-2 border-slate-300"></div>

        {/* Step 4 Loop */}
        <motion.div variants={itemVariants} className="col-span-1 flex flex-col items-center">
          <div className="bg-indigo-50 border border-indigo-100 p-4 rounded-lg w-full h-32 flex flex-col items-center justify-center shadow-sm relative z-10">
             <div className="absolute -top-3 -right-3 bg-indigo-500 text-white text-[10px] px-2 py-0.5 rounded-full shadow-sm">Loop</div>
             <MessageSquare className="w-6 h-6 text-indigo-600 mb-2" />
             <p className="font-bold text-xs text-center">LLM Generation</p>
             <p className="text-[10px] text-slate-500 text-center">Prompt +<br/>議事録 + Question</p>
          </div>
        </motion.div>

        {/* Arrow */}
        <div className="absolute top-8 left-[75%] w-[10%] border-t-2 border-slate-300"></div>

        {/* Step 5 */}
        <motion.div variants={itemVariants} className="col-span-1 flex flex-col items-center">
          <div className="bg-emerald-50 border border-emerald-100 p-4 rounded-lg w-full h-32 flex flex-col items-center justify-center shadow-sm z-10">
             <FileOutput className="w-6 h-6 text-emerald-600 mb-2" />
             <p className="font-bold text-xs text-center">Output</p>
             <p className="text-[10px] text-slate-500 text-center">指摘一覧報告</p>
          </div>
        </motion.div>

      </div>
    </motion.div>
  );
};
