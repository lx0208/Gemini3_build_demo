import React from 'react';
import { Logo } from './Logo';
import { motion } from 'framer-motion';

interface LayoutProps {
  children: React.ReactNode;
  currentSlideIndex: number;
  totalSlides: number;
  sectionTitle?: string;
}

export const Layout: React.FC<LayoutProps> = ({ 
  children, 
  currentSlideIndex, 
  totalSlides,
  sectionTitle 
}) => {
  return (
    <div className="relative w-screen h-screen bg-gradient-to-br from-slate-50 to-slate-200 text-slate-800 overflow-hidden flex flex-col">
      
      {/* Integrated Header */}
      <header className="absolute top-0 left-0 w-full p-6 flex justify-between items-start z-20 pointer-events-none">
        <div className="flex flex-col">
           {/* Breadcrumb Section Title - Only visible if provided */}
          {sectionTitle && (
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="text-sm font-medium text-slate-400 tracking-wider mb-1"
            >
              {sectionTitle}
            </motion.div>
          )}
        </div>

        <div className="flex items-center space-x-3 opacity-80">
          <div className="text-right">
            <h1 className="text-xs font-bold tracking-widest uppercase text-slate-500">日本智明</h1>
            <h2 className="text-xs font-serif-jp text-slate-400">生産技術部</h2>
          </div>
          <div className="h-8 w-[1px] bg-slate-300 mx-2"></div>
          <Logo className="w-8 h-8 text-slate-600" />
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 w-full h-full relative z-10">
        {children}
      </main>

      {/* Footer / Progress */}
      <footer className="absolute bottom-0 left-0 w-full p-6 flex justify-between items-end z-20 pointer-events-none">
        <div className="text-[10px] text-slate-400">
           CONFIDENTIAL - INTERNAL USE ONLY
        </div>
        <div className="text-sm font-mono text-slate-400">
          {currentSlideIndex + 1} <span className="text-slate-300">/</span> {totalSlides}
        </div>
      </footer>

      {/* Decorative Background Elements for "Japanese Minimalism" */}
      <div className="absolute -bottom-20 -left-20 w-96 h-96 bg-indigo-50 rounded-full blur-3xl opacity-50 z-0 pointer-events-none"></div>
      <div className="absolute top-1/4 right-0 w-64 h-64 bg-slate-100 rounded-full blur-3xl opacity-40 z-0 pointer-events-none"></div>
    </div>
  );
};