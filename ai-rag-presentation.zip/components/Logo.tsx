import React from 'react';

export const Logo: React.FC<{ className?: string }> = ({ className }) => {
  return (
    <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Abstract representation of "Intellect/Smart" and "Structure" */}
      <circle cx="50" cy="50" r="45" stroke="currentColor" strokeWidth="2" />
      <path d="M50 20V80" stroke="currentColor" strokeWidth="2" />
      <path d="M20 50H80" stroke="currentColor" strokeWidth="2" />
      <rect x="35" y="35" width="30" height="30" transform="rotate(45 50 50)" stroke="currentColor" strokeWidth="2" />
      <circle cx="50" cy="50" r="5" fill="currentColor" />
    </svg>
  );
};