import { ReactNode } from 'react';

export enum SlideType {
  TITLE = 'TITLE',
  AGENDA = 'AGENDA',
  SECTION = 'SECTION',
  CONTENT = 'CONTENT',
  END = 'END',
}

export interface SlideData {
  id: string;
  type: SlideType;
  title?: string;
  subtitle?: string;
  sectionTitle?: string; // For the "bread crumb" in top left
  content?: ReactNode;
}
