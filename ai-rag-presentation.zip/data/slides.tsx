import React from 'react';
import { SlideData, SlideType } from '../types';
import { BatchImportFlow, ChatResponseFlow } from '../components/Diagrams';
import { Check, X, Code, Terminal, Layers } from 'lucide-react';

export const slides: SlideData[] = [
  // 1. Title Page
  {
    id: 'title',
    type: SlideType.TITLE,
    title: 'AI RAG システム設計',
    subtitle: 'バッチ処理とChat APIの構築',
  },
  
  // 2. Agenda
  {
    id: 'agenda',
    type: SlideType.AGENDA,
    title: '目次',
    content: (
      <ol className="list-none space-y-6 text-2xl font-serif-jp text-slate-700 ml-12">
        <li className="flex items-center">
          <span className="text-4xl font-light text-slate-300 mr-6">01</span>
          LangChainの紹介
        </li>
        <li className="flex items-center">
          <span className="text-4xl font-light text-slate-300 mr-6">02</span>
          RAG - ナレッジベースの導入 (Batch)
        </li>
        <li className="flex items-center">
          <span className="text-4xl font-light text-slate-300 mr-6">03</span>
          RAG - ナレッジベースに基づく回答
        </li>
      </ol>
    )
  },

  // 3. Section 1 Title
  {
    id: 'sec-1',
    type: SlideType.SECTION,
    title: 'LangChainの紹介',
    sectionTitle: '01. LangChainの紹介'
  },

  // 4. LangChain Definition
  {
    id: 'lc-def',
    type: SlideType.CONTENT,
    sectionTitle: '01. LangChainの紹介',
    title: 'LangChainとは',
    content: (
      <div className="flex flex-col justify-center h-full">
        <blockquote className="text-3xl font-serif-jp leading-relaxed text-slate-700 border-l-4 border-slate-300 pl-8 py-4 mb-12">
          「ChatGPTなどの大規模言語モデル(LLM)の機能拡張を<br/>
          効率的に実装するためのライブラリ」
        </blockquote>
        
        <div className="grid grid-cols-2 gap-6">
            <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-100">
                <h3 className="font-bold text-lg mb-4 text-slate-600 border-b pb-2">主な機能・できること</h3>
                <ul className="space-y-3">
                    <li className="flex items-center text-slate-700"><Check className="w-5 h-5 mr-3 text-emerald-500"/> Model I/O (モデル選択の統一化)</li>
                    <li className="flex items-center text-slate-700"><Check className="w-5 h-5 mr-3 text-emerald-500"/> Retrieval (外部データの検索)</li>
                    <li className="flex items-center text-slate-700"><Check className="w-5 h-5 mr-3 text-emerald-500"/> Chains (処理の連鎖・フロー化)</li>
                    <li className="flex items-center text-slate-700"><Check className="w-5 h-5 mr-3 text-emerald-500"/> Agents (自律的なタスク実行)</li>
                </ul>
            </div>
            <div className="bg-slate-50 p-6 rounded-lg border border-slate-100">
                 <h3 className="font-bold text-lg mb-4 text-slate-600 border-b pb-2">導入メリット</h3>
                 <ul className="space-y-3 text-sm text-slate-600">
                    <li>・ インフラ環境への依存度を下げる</li>
                    <li>・ 拡張性（将来的にモデルを変更しやすい）</li>
                    <li>・ カスタム機能の実装コスト削減</li>
                 </ul>
            </div>
        </div>
      </div>
    )
  },

  // 5. Code Comparison
  {
    id: 'lc-compare',
    type: SlideType.CONTENT,
    sectionTitle: '01. LangChainの紹介',
    title: '実装比較: Direct API vs LangChain',
    content: (
      <div className="grid grid-cols-2 gap-8 h-full">
        
        {/* Direct API */}
        <div className="flex flex-col">
          <div className="flex items-center mb-2 text-red-400">
            <X className="w-5 h-5 mr-2" />
            <span className="font-bold text-sm">Direct API Call</span>
          </div>
          <div className="flex-1 bg-slate-800 rounded-lg p-4 text-xs font-mono text-slate-300 overflow-hidden relative group">
            <div className="absolute top-2 right-2 text-slate-600 opacity-20"><Code className="w-16 h-16"/></div>
            <p className="text-green-400">import</p> openai<br/><br/>
            client = openai.Client(...)<br/>
            response = client.chat.completions.create(<br/>
            &nbsp;&nbsp;model="gpt-4",<br/>
            &nbsp;&nbsp;messages=[...]<br/>
            )<br/>
            <span className="text-slate-500 block mt-4 text-[10px]"># モデル変更時にコード修正が必要</span>
            <span className="text-slate-500 block text-[10px]"># 履歴管理を自前で実装が必要</span>
          </div>
        </div>

        {/* LangChain */}
        <div className="flex flex-col">
           <div className="flex items-center mb-2 text-emerald-500">
            <Check className="w-5 h-5 mr-2" />
            <span className="font-bold text-sm">LangChain</span>
          </div>
          <div className="flex-1 bg-slate-800 rounded-lg p-4 text-xs font-mono text-slate-300 overflow-hidden relative">
             <div className="absolute top-2 right-2 text-slate-600 opacity-20"><Layers className="w-16 h-16"/></div>
             <p className="text-pink-400">from</p> langchain.chat_models <p className="text-pink-400 inline">import</p> ChatOpenAI<br/><br/>
             llm = ChatOpenAI(model_name="gpt-4")<br/>
             response = llm.predict(message)<br/>
             <span className="text-slate-500 block mt-4 text-[10px]"># モデルの切り替えが設定のみで可能</span>
             <span className="text-slate-500 block text-[10px]"># Memoryクラスで履歴管理が容易</span>
          </div>
        </div>

      </div>
    )
  },

  // 6. Section 2 Title
  {
    id: 'sec-2',
    type: SlideType.SECTION,
    title: 'RAG - ナレッジベースの導入',
    subtitle: 'Batch処理の設計',
    sectionTitle: '02. RAG - ナレッジベースの導入 (Batch)'
  },

  // 7. Batch Flow
  {
    id: 'batch-flow',
    type: SlideType.CONTENT,
    sectionTitle: '02. RAG - ナレッジベースの導入 (Batch)',
    title: 'データ取込フロー',
    content: (
      <div className="h-full flex flex-col justify-center">
         <div className="mb-8">
            <BatchImportFlow />
         </div>
         <div className="grid grid-cols-3 gap-4 text-xs text-slate-600 bg-white p-4 rounded-lg border border-slate-200">
            <div>
                <strong className="block text-slate-800 mb-1">Document Loaders</strong>
                <p>非構造化データを標準フォーマット(Document Object)へ統一。</p>
            </div>
            <div>
                <strong className="block text-slate-800 mb-1">Text Splitters</strong>
                <p>LLMのToken制限(Window size)に合わせて、文脈を維持しつつ分割。</p>
            </div>
             <div>
                <strong className="block text-slate-800 mb-1">PGVector</strong>
                <p>PostgreSQLの拡張機能。ベクトルデータを直接SQLで扱えるため管理が容易。</p>
            </div>
         </div>
      </div>
    )
  },

  // 8. Section 3 Title
  {
    id: 'sec-3',
    type: SlideType.SECTION,
    title: 'RAG - ナレッジベースに基づく回答',
    subtitle: 'Chat APIのロジック設計',
    sectionTitle: '03. RAG - 根据知识库回答'
  },

  // 9. Chat Flow
  {
    id: 'chat-flow',
    type: SlideType.CONTENT,
    sectionTitle: '03. RAG - 根据知识库回答',
    title: '回答生成フロー',
    content: (
      <div className="h-full flex flex-col justify-center">
         <p className="text-sm text-slate-500 mb-8 ml-2">前提：知識庫はPostgreSQLにインポート済みとする</p>
         <ChatResponseFlow />
         <div className="mt-8 bg-amber-50 border-l-4 border-amber-300 p-4 rounded-r text-sm text-slate-700">
            <h4 className="font-bold flex items-center mb-2"><Terminal className="w-4 h-4 mr-2"/> ポイント</h4>
            <ul className="list-disc ml-6 space-y-1">
                <li>Retrievalで抽出するのは「答え」ではなく「関連ドキュメント（計画書）」。</li>
                <li>ドキュメントIDをキーにして、関連する「議事録」を全件取得するロジックを挟む。</li>
                <li>LLMには、ユーザーの質問だけでなく、関連議事録の文脈も与えることで精度を高める。</li>
            </ul>
         </div>
      </div>
    )
  },

  // 10. End Page
  {
    id: 'end',
    type: SlideType.END,
    title: 'ご清聴ありがとうございました',
    subtitle: 'Q & A',
  }
];