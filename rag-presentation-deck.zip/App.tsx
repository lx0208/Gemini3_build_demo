import React, { useState, useEffect, useCallback } from 'react';
import { ChevronRight, ChevronLeft, Terminal, FileText, Database, Search, Cpu, Zap, MessageCircle } from 'lucide-react';
import { RagDiagram } from './components/RagDiagram';
import { DiagramPart, SlideDef } from './types';
import { askRagQuestion } from './services/gemini';

// --- Helper Components ---

const SlideWrapper: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div className="w-full h-full flex flex-col items-center justify-center p-8 md:p-16 relative animate-fade-in">
    {children}
  </div>
);

const BulletPoint: React.FC<{ children: React.ReactNode; delay?: number }> = ({ children, delay = 0 }) => (
  <div 
    className="flex items-start gap-4 text-xl md:text-2xl text-slate-300 mb-6 transition-all duration-700 ease-out transform translate-y-0 opacity-100"
    style={{ animation: `slideUp 0.5s ease-out ${delay}ms backwards` }}
  >
    <div className="mt-2 w-2 h-2 rounded-full bg-sky-400 shrink-0" />
    <div className="leading-relaxed font-light tracking-wide">{children}</div>
  </div>
);

const SectionTitle: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <h2 className="text-4xl md:text-5xl font-bold text-white mb-12 bg-clip-text text-transparent bg-gradient-to-r from-sky-400 to-indigo-400">
    {children}
  </h2>
);

// --- Main App ---

export default function App() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [qaInput, setQaInput] = useState("");
  const [qaAnswer, setQaAnswer] = useState("");
  const [isThinking, setIsThinking] = useState(false);

  // --- Slide Definitions ---

  const slides: SlideDef[] = [
    // Slide 0: Title
    {
      id: 'title',
      title: 'AI RAG 技術解説',
      component: (
        <SlideWrapper>
          <div className="text-center">
            <div className="inline-block p-4 rounded-full bg-sky-500/10 mb-6 animate-pulse">
              <Database className="w-16 h-16 text-sky-400" />
            </div>
            <h1 className="text-6xl md:text-8xl font-bold text-white mb-6 tracking-tight">
              AI <span className="text-sky-400">RAG</span>
            </h1>
            <p className="text-2xl text-slate-400 max-w-2xl mx-auto font-mono">
              Retrieval-Augmented Generation<br/>
              <span className="text-base text-slate-500 mt-2 block">検索拡張生成の仕組み</span>
            </p>
            <div className="mt-12 flex justify-center gap-4">
              <div className="px-6 py-3 rounded-lg border border-slate-700 bg-slate-800/50 text-slate-400">
                Data (知識)
              </div>
              <div className="px-6 py-3 rounded-lg border border-slate-700 bg-slate-800/50 text-slate-400">
                +
              </div>
              <div className="px-6 py-3 rounded-lg border border-slate-700 bg-slate-800/50 text-slate-400">
                LLM (生成)
              </div>
            </div>
          </div>
        </SlideWrapper>
      )
    },
    // Slide 1: Agenda / Overview
    {
      id: 'agenda',
      title: 'Workflow Overview',
      component: (
        <SlideWrapper>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 w-full max-w-7xl items-center">
            <div>
              <SectionTitle>RAGの4つのステップ</SectionTitle>
              <div className="space-y-4">
                 <BulletPoint delay={100}>
                   <strong className="text-white">1. Indexing (インデックス化):</strong><br/>
                   <span className="text-slate-400 text-lg">知識データの準備とVector化</span>
                 </BulletPoint>
                 <BulletPoint delay={200}>
                   <strong className="text-white">2. Retrieval (検索):</strong><br/>
                   <span className="text-slate-400 text-lg">質問に関連する情報の抽出</span>
                 </BulletPoint>
                 <BulletPoint delay={300}>
                   <strong className="text-white">3. Augmentation (拡張):</strong><br/>
                   <span className="text-slate-400 text-lg">文脈(Context)の構築</span>
                 </BulletPoint>
                 <BulletPoint delay={400}>
                   <strong className="text-white">4. Generation (生成):</strong><br/>
                   <span className="text-slate-400 text-lg">LLMによる回答作成</span>
                 </BulletPoint>
              </div>
              <div className="mt-12 p-6 bg-slate-800/50 border-l-4 border-sky-500 rounded-r-lg">
                <p className="text-slate-300 italic">
                  "LLMの一般的な知識と、組織固有の最新データを繋ぐ架け橋"
                </p>
              </div>
            </div>
            <div className="h-[400px] bg-slate-900/50 rounded-2xl border border-slate-700/50 p-4">
               <RagDiagram activePart={DiagramPart.NONE} />
            </div>
          </div>
        </SlideWrapper>
      )
    },
    // Slide 2: Step 1 - Indexing
    {
      id: 'step1',
      title: 'Step 1: Indexing',
      component: (
        <SlideWrapper>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 w-full max-w-7xl items-center">
            <div className="order-2 lg:order-1">
               <div className="transform scale-110">
                 <RagDiagram activePart={DiagramPart.VECTOR_DB} />
               </div>
            </div>
            <div className="order-1 lg:order-2">
              <div className="flex items-center gap-4 mb-6">
                 <div className="p-3 bg-purple-500/20 rounded-lg text-purple-400"><FileText size={32}/></div>
                 <h2 className="text-4xl font-bold text-white">Indexing</h2>
              </div>
              <BulletPoint delay={100}>ドキュメント（PDF, Wiki, 社内DB）を適切なサイズに分割（Chunking）。</BulletPoint>
              <BulletPoint delay={200}><strong>Embedding Model</strong> を使用して、テキストを数値列（Vector）に変換。</BulletPoint>
              <BulletPoint delay={300}><strong>Vector Database</strong> に保存し、意味検索が可能な状態にする。</BulletPoint>
            </div>
          </div>
        </SlideWrapper>
      )
    },
    // Slide 3: Step 2 & 3 - Retrieval & Augmentation
    {
      id: 'step2',
      title: 'Step 2 & 3: Retrieval & Augmentation',
      component: (
        <SlideWrapper>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 w-full max-w-7xl items-center">
            <div>
              <div className="flex items-center gap-4 mb-6">
                 <div className="p-3 bg-yellow-500/20 rounded-lg text-yellow-400"><Search size={32}/></div>
                 <h2 className="text-4xl font-bold text-white">Retrieval & Augmentation</h2>
              </div>
              
              <div className="mb-8">
                <h3 className="text-sky-400 text-xl font-bold mb-2">Step 2: Retrieval (検索)</h3>
                <BulletPoint delay={100}>ユーザーの質問をVector化。</BulletPoint>
                <BulletPoint delay={200}><strong>Semantic Search</strong> (意味検索) で類似性の高いデータをVector DBから抽出。</BulletPoint>
              </div>

              <div className="h-px bg-slate-700 my-6 w-full"></div>

              <div>
                <h3 className="text-green-400 text-xl font-bold mb-2">Step 3: Augmentation (拡張)</h3>
                <BulletPoint delay={300}>抽出した情報をPromptに統合。</BulletPoint>
                <BulletPoint delay={400}>LLMに渡すための <strong>Context (文脈)</strong> を構築。</BulletPoint>
              </div>
            </div>
            <div className="transform scale-110">
                <RagDiagram activePart={DiagramPart.CONTEXT} />
            </div>
          </div>
        </SlideWrapper>
      )
    },
    // Slide 4: Step 4 - Generation
    {
      id: 'step4',
      title: 'Step 4: Generation',
      component: (
        <SlideWrapper>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 w-full max-w-7xl items-center">
            <div className="order-2 lg:order-1">
               <div className="transform scale-110">
                 <RagDiagram activePart={DiagramPart.LLM} />
               </div>
            </div>
             <div className="order-1 lg:order-2">
              <div className="flex items-center gap-4 mb-6">
                 <div className="p-3 bg-pink-500/20 rounded-lg text-pink-400"><Cpu size={32}/></div>
                 <h2 className="text-4xl font-bold text-white">Generation</h2>
              </div>
              <BulletPoint delay={100}>LLMへの入力:<br/><span className="text-sm font-mono text-slate-400 bg-slate-800 p-2 rounded block mt-2">System Prompt + Context + Question</span></BulletPoint>
              <BulletPoint delay={200}>提供された <strong>Context</strong> のみに基づいて回答を生成。</BulletPoint>
              <BulletPoint delay={300}><strong>Hallucination</strong> (事実と異なる生成) を抑制し、情報の出典を明確にする。</BulletPoint>
            </div>
          </div>
        </SlideWrapper>
      )
    },
    // Slide 5: Interactive Demo
    {
      id: 'demo',
      title: 'Ask AI',
      component: (
        <SlideWrapper>
          <div className="w-full max-w-4xl text-center">
             <SectionTitle>Q&A Demo</SectionTitle>
             <p className="text-slate-400 mb-8">AIにRAGについて質問してみましょう。</p>
             
             <div className="flex gap-4 mb-8">
               <input 
                 type="text" 
                 value={qaInput}
                 onChange={(e) => setQaInput(e.target.value)}
                 onKeyDown={(e) => e.key === 'Enter' && !isThinking && handleAsk()}
                 placeholder="例: Vector Databaseとは何ですか？"
                 className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-6 py-4 text-white text-lg focus:outline-none focus:border-sky-500 transition-colors"
               />
               <button 
                 onClick={() => handleAsk()}
                 disabled={isThinking || !qaInput.trim()}
                 className={`px-8 py-4 bg-sky-500 hover:bg-sky-400 text-white font-bold rounded-xl transition-all flex items-center gap-2 ${isThinking ? 'opacity-50 cursor-not-allowed' : ''}`}
               >
                 {isThinking ? '思考中...' : <><MessageCircle /> 質問する</>}
               </button>
             </div>

             {qaAnswer && (
               <div className="bg-slate-800/80 border border-slate-700 rounded-xl p-8 text-left animate-fade-in">
                 <div className="flex items-center gap-3 mb-4 text-sky-400">
                    <Terminal size={20} />
                    <span className="font-mono font-bold">Gemini Response</span>
                 </div>
                 <p className="text-lg text-slate-200 leading-relaxed whitespace-pre-line">{qaAnswer}</p>
               </div>
             )}
          </div>
        </SlideWrapper>
      )
    }
  ];

  const handleAsk = async () => {
    if (!qaInput.trim()) return;
    setIsThinking(true);
    setQaAnswer("");
    const answer = await askRagQuestion(qaInput);
    setQaAnswer(answer);
    setIsThinking(false);
  };

  // --- Navigation Logic ---

  const nextSlide = useCallback(() => {
    setCurrentSlide(prev => Math.min(prev + 1, slides.length - 1));
  }, [slides.length]);

  const prevSlide = useCallback(() => {
    setCurrentSlide(prev => Math.max(prev - 0, 0));
  }, []);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight' || e.key === 'Space') nextSlide();
      if (e.key === 'ArrowLeft') prevSlide();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [nextSlide, prevSlide]);

  return (
    <div className="bg-slide-bg text-slide-text w-screen h-screen relative overflow-hidden font-sans selection:bg-sky-500/30">
      
      {/* Background Ambience */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none z-0">
         <div className="absolute top-[-20%] right-[-10%] w-[800px] h-[800px] bg-sky-600/10 rounded-full blur-[120px]" />
         <div className="absolute bottom-[-20%] left-[-10%] w-[600px] h-[600px] bg-indigo-600/10 rounded-full blur-[100px]" />
      </div>

      {/* Main Content Area */}
      <main className="relative z-10 w-full h-full">
        {slides[currentSlide].component}
      </main>

      {/* Controls / Progress */}
      <div className="absolute bottom-8 right-8 z-50 flex items-center gap-4">
        <span className="text-slate-500 font-mono text-sm">
          {currentSlide + 1} / {slides.length}
        </span>
        <div className="flex gap-2">
          <button 
            onClick={prevSlide}
            disabled={currentSlide === 0}
            className="p-3 rounded-full bg-slate-800 hover:bg-slate-700 disabled:opacity-30 disabled:cursor-not-allowed transition-colors border border-slate-700"
          >
            <ChevronLeft size={24} />
          </button>
          <button 
            onClick={nextSlide}
            disabled={currentSlide === slides.length - 1}
            className="p-3 rounded-full bg-sky-600 hover:bg-sky-500 disabled:opacity-30 disabled:cursor-not-allowed transition-colors text-white shadow-lg shadow-sky-900/20"
          >
            <ChevronRight size={24} />
          </button>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="absolute bottom-0 left-0 w-full h-1 bg-slate-800">
        <div 
          className="h-full bg-gradient-to-r from-sky-400 to-indigo-500 transition-all duration-500"
          style={{ width: `${((currentSlide + 1) / slides.length) * 100}%` }}
        />
      </div>

      {/* CSS Animations */}
      <style>{`
        @keyframes slideUp {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in {
          animation: slideUp 0.8s cubic-bezier(0.16, 1, 0.3, 1);
        }
      `}</style>
    </div>
  );
}