import React, { useState } from 'react';
import { DiagramPart } from '../types';
import { Database, Brain, User, FileText, Search, MessageSquare, ArrowRight } from 'lucide-react';

interface RagDiagramProps {
  activePart?: DiagramPart; // Controlled from outside if needed
  onPartHover?: (part: DiagramPart) => void;
}

export const RagDiagram: React.FC<RagDiagramProps> = ({ activePart: externalActivePart, onPartHover }) => {
  const [internalActivePart, setInternalActivePart] = useState<DiagramPart>(DiagramPart.NONE);
  
  const currentPart = externalActivePart || internalActivePart;

  const handleEnter = (part: DiagramPart) => {
    setInternalActivePart(part);
    if (onPartHover) onPartHover(part);
  };

  const handleLeave = () => {
    setInternalActivePart(DiagramPart.NONE);
    if (onPartHover) onPartHover(DiagramPart.NONE);
  };

  const getOpacity = (part: DiagramPart) => {
    if (currentPart === DiagramPart.NONE) return 1;
    return currentPart === part ? 1 : 0.3;
  };

  const getStroke = (part: DiagramPart) => {
    return currentPart === part ? "#38bdf8" : "#475569";
  };

  const getFill = (part: DiagramPart) => {
    return currentPart === part ? "rgba(56, 189, 248, 0.2)" : "rgba(30, 41, 59, 0.5)";
  };

  return (
    <div className="w-full h-full flex items-center justify-center p-4">
      <svg 
        viewBox="0 0 800 500" 
        className="w-full max-w-5xl h-auto drop-shadow-2xl font-sans"
        style={{ overflow: 'visible' }}
      >
        <defs>
          <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
            <polygon points="0 0, 10 3.5, 0 7" fill="#94a3b8" />
          </marker>
          <marker id="arrowhead-active" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
            <polygon points="0 0, 10 3.5, 0 7" fill="#38bdf8" />
          </marker>
          <filter id="glow">
            <feGaussianBlur stdDeviation="2.5" result="coloredBlur"/>
            <feMerge>
                <feMergeNode in="coloredBlur"/>
                <feMergeNode in="SourceGraphic"/>
            </feMerge>
          </filter>
        </defs>

        {/* --- 1. User & Query --- */}
        <g 
          transform="translate(50, 200)" 
          onMouseEnter={() => handleEnter(DiagramPart.USER)}
          onMouseLeave={handleLeave}
          style={{ cursor: 'pointer', opacity: getOpacity(DiagramPart.USER) }}
        >
          <rect x="-20" y="-40" width="100" height="120" rx="10" fill={getFill(DiagramPart.USER)} stroke={getStroke(DiagramPart.USER)} strokeWidth="2" />
          <User className="text-white" x="10" y="-20" width="40" height="40" color="white" />
          <text x="30" y="40" textAnchor="middle" fill="white" fontSize="14" fontWeight="600">User</text>
          <text x="30" y="60" textAnchor="middle" fill="#94a3b8" fontSize="10">質問 (Input)</text>
        </g>

        {/* --- 2. Embedding Model --- */}
        <g 
          transform="translate(250, 100)" 
          onMouseEnter={() => handleEnter(DiagramPart.EMBEDDING)}
          onMouseLeave={handleLeave}
          style={{ cursor: 'pointer', opacity: getOpacity(DiagramPart.EMBEDDING) }}
        >
          <circle cx="0" cy="0" r="50" fill={getFill(DiagramPart.EMBEDDING)} stroke={getStroke(DiagramPart.EMBEDDING)} strokeWidth="2" />
          <Brain x="-20" y="-20" width="40" height="40" color="#a78bfa" />
          <text x="0" y="70" textAnchor="middle" fill="white" fontSize="14" fontWeight="600">Embedding</text>
          <text x="0" y="90" textAnchor="middle" fill="#94a3b8" fontSize="10">Vector化</text>
        </g>

        {/* --- 3. Vector DB --- */}
        <g 
          transform="translate(450, 100)" 
          onMouseEnter={() => handleEnter(DiagramPart.VECTOR_DB)}
          onMouseLeave={handleLeave}
          style={{ cursor: 'pointer', opacity: getOpacity(DiagramPart.VECTOR_DB) }}
        >
          <path d="M-40,-30 L40,-30 L40,30 L-40,30 Z" fill={getFill(DiagramPart.VECTOR_DB)} stroke={getStroke(DiagramPart.VECTOR_DB)} strokeWidth="2" />
           {/* Cylinder shape for DB */}
          <path d="M-40,-30 A 40 10 0 0 1 40 -30 A 40 10 0 0 1 -40 -30" fill="none" stroke={getStroke(DiagramPart.VECTOR_DB)} />
          <path d="M-40,30 A 40 10 0 0 0 40 30 A 40 10 0 0 0 -40 30" fill="none" stroke={getStroke(DiagramPart.VECTOR_DB)} />
          <line x1="-40" y1="-30" x2="-40" y2="30" stroke={getStroke(DiagramPart.VECTOR_DB)} />
          <line x1="40" y1="-30" x2="40" y2="30" stroke={getStroke(DiagramPart.VECTOR_DB)} />
          
          <Database x="-15" y="-15" width="30" height="30" color="#fbbf24" />
          <text x="0" y="60" textAnchor="middle" fill="white" fontSize="14" fontWeight="600">Vector DB</text>
          <text x="0" y="80" textAnchor="middle" fill="#94a3b8" fontSize="10">知識ベース</text>
        </g>

        {/* --- 4. Context Construction --- */}
        <g 
          transform="translate(450, 300)" 
          onMouseEnter={() => handleEnter(DiagramPart.CONTEXT)}
          onMouseLeave={handleLeave}
          style={{ cursor: 'pointer', opacity: getOpacity(DiagramPart.CONTEXT) }}
        >
          <rect x="-60" y="-40" width="120" height="80" rx="4" fill={getFill(DiagramPart.CONTEXT)} stroke={getStroke(DiagramPart.CONTEXT)} strokeWidth="2" strokeDasharray="5,5" />
          <FileText x="-15" y="-20" width="30" height="30" color="#34d399" />
          <text x="0" y="60" textAnchor="middle" fill="white" fontSize="14" fontWeight="600">Context</text>
          <text x="0" y="80" textAnchor="middle" fill="#94a3b8" fontSize="10">拡張プロンプト</text>
        </g>

        {/* --- 5. LLM --- */}
        <g 
          transform="translate(650, 200)" 
          onMouseEnter={() => handleEnter(DiagramPart.LLM)}
          onMouseLeave={handleLeave}
          style={{ cursor: 'pointer', opacity: getOpacity(DiagramPart.LLM) }}
        >
          <rect x="-50" y="-50" width="100" height="100" rx="15" fill={getFill(DiagramPart.LLM)} stroke={getStroke(DiagramPart.LLM)} strokeWidth="2" />
          <Brain x="-25" y="-25" width="50" height="50" color="#f472b6" />
          <text x="0" y="70" textAnchor="middle" fill="white" fontSize="14" fontWeight="600">LLM</text>
          <text x="0" y="90" textAnchor="middle" fill="#94a3b8" fontSize="10">回答生成</text>
        </g>

        {/* --- CONNECTORS --- */}
        
        {/* User -> Query Flow (Splits to Embedding and LLM context) */}
        <path 
          d="M 130 220 L 180 220 L 180 100 L 200 100" 
          fill="none" 
          stroke={currentPart === DiagramPart.EMBEDDING ? "#38bdf8" : "#475569"} 
          strokeWidth="2" 
          markerEnd={currentPart === DiagramPart.EMBEDDING ? "url(#arrowhead-active)" : "url(#arrowhead)"}
        />
        
        {/* Embedding -> Vector DB */}
        <path 
          d="M 300 100 L 410 100" 
          fill="none" 
          stroke={currentPart === DiagramPart.VECTOR_DB ? "#38bdf8" : "#475569"} 
          strokeWidth="2" 
          markerEnd={currentPart === DiagramPart.VECTOR_DB ? "url(#arrowhead-active)" : "url(#arrowhead)"}
        />

        {/* Vector DB -> Context */}
        <path 
          d="M 450 140 L 450 250" 
          fill="none" 
          stroke={currentPart === DiagramPart.RETRIEVAL ? "#38bdf8" : "#475569"} 
          strokeWidth="2" 
          markerEnd={currentPart === DiagramPart.RETRIEVAL ? "url(#arrowhead-active)" : "url(#arrowhead)"}
          strokeDasharray="4"
        />
        <text x="460" y="200" fill="#94a3b8" fontSize="10">類似検索</text>

        {/* Query -> Context (Pass through) */}
        <path 
          d="M 130 240 L 380 240 L 380 300 L 390 300" 
          fill="none" 
          stroke={currentPart === DiagramPart.CONTEXT ? "#38bdf8" : "#475569"} 
          strokeWidth="2" 
          markerEnd={currentPart === DiagramPart.CONTEXT ? "url(#arrowhead-active)" : "url(#arrowhead)"}
        />

        {/* Context -> LLM */}
        <path 
          d="M 510 300 L 550 300 L 550 220 L 600 220" 
          fill="none" 
          stroke={currentPart === DiagramPart.LLM ? "#38bdf8" : "#475569"} 
          strokeWidth="2" 
          markerEnd={currentPart === DiagramPart.LLM ? "url(#arrowhead-active)" : "url(#arrowhead)"}
        />

        {/* LLM -> User Response */}
        <path 
          d="M 650 250 L 650 350 L 100 350 L 100 280" 
          fill="none" 
          stroke={currentPart === DiagramPart.RESPONSE ? "#38bdf8" : "#475569"} 
          strokeWidth="2" 
          markerEnd={currentPart === DiagramPart.RESPONSE ? "url(#arrowhead-active)" : "url(#arrowhead)"}
          strokeDasharray="5,2"
        />
         <text x="350" y="370" textAnchor="middle" fill="#94a3b8" fontSize="12">Final Answer</text>

      </svg>
      
      {/* Tooltip Area (Fixed position relative to svg container) */}
      <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 h-16 pointer-events-none w-full text-center">
        {currentPart === DiagramPart.USER && <div className="inline-block bg-slate-800 text-sky-400 px-4 py-2 rounded-lg border border-sky-500/30">Step 0: ユーザーが質問を入力します。</div>}
        {currentPart === DiagramPart.EMBEDDING && <div className="inline-block bg-slate-800 text-sky-400 px-4 py-2 rounded-lg border border-sky-500/30">Step 1: テキストを数値（Vector）に変換します。</div>}
        {currentPart === DiagramPart.VECTOR_DB && <div className="inline-block bg-slate-800 text-sky-400 px-4 py-2 rounded-lg border border-sky-500/30">Step 2: 知識データをVectorとして保存します。</div>}
        {currentPart === DiagramPart.RETRIEVAL && <div className="inline-block bg-slate-800 text-sky-400 px-4 py-2 rounded-lg border border-sky-500/30">Step 3: 関連する情報を検索・抽出します（Retrieval）。</div>}
        {currentPart === DiagramPart.CONTEXT && <div className="inline-block bg-slate-800 text-sky-400 px-4 py-2 rounded-lg border border-sky-500/30">Step 3.5: 質問と検索結果を組み合わせてContextを作ります。</div>}
        {currentPart === DiagramPart.LLM && <div className="inline-block bg-slate-800 text-sky-400 px-4 py-2 rounded-lg border border-sky-500/30">Step 4: LLMがContextに基づいて回答を生成します。</div>}
      </div>
    </div>
  );
};