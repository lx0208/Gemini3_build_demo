export enum SlideType {
  START = 'START',
  HISTORY = 'HISTORY',
  RAG_INTRO = 'RAG_INTRO',
  PROJECT_DETAIL = 'PROJECT_DETAIL',
  END = 'END'
}

export interface SlideProps {
  isActive: boolean;
}