import React, { ReactNode } from 'react';
import { motion } from 'framer-motion';

interface SlideLayoutProps {
  children: ReactNode;
  className?: string;
}

export const SlideLayout: React.FC<SlideLayoutProps> = ({ children, className = "" }) => {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20, filter: 'blur(10px)' }}
      animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
      exit={{ opacity: 0, y: -20, filter: 'blur(10px)' }}
      transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
      className={`w-full h-full flex flex-col px-16 py-24 max-w-7xl mx-auto relative ${className}`}
    >
      {/* Japanese decorative background element */}
      <div className="absolute top-0 right-10 w-px h-32 bg-gradient-to-b from-sumi/20 to-transparent" />
      {children}
    </motion.div>
  );
};