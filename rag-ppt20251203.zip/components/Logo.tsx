import React from 'react';

export const Logo: React.FC<{ className?: string }> = ({ className }) => {
  return (
    <svg 
      className={className} 
      viewBox="0 0 100 100" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* Abstract representation of "Chimei" (Wisdom/Light) and Precision Engineering */}
      <circle cx="50" cy="50" r="45" stroke="currentColor" strokeWidth="2" className="opacity-20" />
      <path d="M50 20 L50 40" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      <path d="M50 60 L50 80" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      <path d="M20 50 L40 50" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      <path d="M60 50 L80 50" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      
      {/* Central geometric flower/tech node */}
      <rect x="42" y="42" width="16" height="16" transform="rotate(45 50 50)" fill="#a63737" />
      <circle cx="50" cy="50" r="4" fill="#f9f8f6" />
    </svg>
  );
};