import React from 'react';
import { SlideLayout } from '../components/SlideLayout';
import { GitFork, Layers, Image as ImageIcon, MessageCircle, Cpu } from 'lucide-react';

export const FutureOutlookSlide: React.FC = () => {
  return (
    <SlideLayout>
      <div className="mb-8 border-l-4 border-kurenai pl-6">
        <h2 className="text-3xl font-serif font-bold text-sumi mb-2">今後の展望</h2>
        <p className="text-usuzumi font-serif">Future Outlook: Toward Advanced RAG</p>
      </div>

      <div className="flex flex-col gap-8 h-full">
        {/* Top Section: Modular RAG */}
        <div className="flex-1 bg-white rounded-xl p-6 border border-sumi/5 shadow-sm flex flex-col md:flex-row gap-6">
          <div className="flex-1 space-y-4">
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 bg-kurenai/10 rounded-lg">
                <GitFork className="w-6 h-6 text-kurenai" />
              </div>
              <h3 className="text-xl font-bold font-serif text-sumi">Modular RAG への進化</h3>
            </div>
            <p className="text-sm text-sumi/80 font-serif leading-relaxed">
              案件の複雑化に伴い、従来の一直線(Linear)なRAGから、
              動的に処理を選択する<span className="font-bold text-kurenai">Modular RAG</span>へ移行します。
              クエリの種類に応じて、検索、記憶、計算などのモジュールを自律的に使い分けます。
            </p>
          </div>
          
          {/* Visual Representation of Modular RAG */}
          <div className="flex-1 bg-stone-50 rounded-lg border border-sumi/5 p-4 flex items-center justify-center relative overflow-hidden">
            <div className="flex flex-col items-center gap-2 w-full">
               {/* Router */}
               <div className="bg-sumi text-white px-4 py-1 rounded text-xs font-bold mb-4 relative">
                  Router / Planner
                  <div className="absolute -bottom-4 left-1/2 w-px h-4 bg-sumi/30 -translate-x-1/2"></div>
               </div>
               {/* Modules */}
               <div className="flex gap-2 w-full justify-center">
                  <div className="bg-white border border-kurenai text-kurenai px-2 py-2 rounded text-[10px] shadow-sm w-20 text-center font-bold">Search</div>
                  <div className="bg-white border border-sumi/20 text-sumi px-2 py-2 rounded text-[10px] shadow-sm w-20 text-center">Memory</div>
                  <div className="bg-white border border-sumi/20 text-sumi px-2 py-2 rounded text-[10px] shadow-sm w-20 text-center">Tools</div>
               </div>
               {/* Convergence */}
               <div className="mt-4 text-[10px] text-usuzumi font-serif tracking-widest">DYNAMIC ORCHESTRATION</div>
            </div>
          </div>
        </div>

        {/* Bottom Section: Multimodal */}
        <div className="flex-1 bg-white rounded-xl p-6 border border-sumi/5 shadow-sm flex flex-col md:flex-row gap-6">
          <div className="flex-1 space-y-4">
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 bg-indigo-50 rounded-lg">
                <Layers className="w-6 h-6 text-indigo-600" />
              </div>
              <h3 className="text-xl font-bold font-serif text-sumi">マルチモーダル対応</h3>
            </div>
            <p className="text-sm text-sumi/80 font-serif leading-relaxed">
              プロジェクト計画書には多くの「図表」や「グラフ」が含まれます。
              テキストだけでなく画像情報もベクトル化し、より深いコンテキスト理解を実現します。
            </p>
          </div>

          {/* Visual Representation of Multimodal */}
          <div className="flex-1 bg-stone-50 rounded-lg border border-sumi/5 p-4 flex items-center justify-around relative">
             <div className="flex flex-col items-center gap-2">
                <div className="w-10 h-10 bg-white rounded border border-sumi/10 flex items-center justify-center shadow-sm">
                   <span className="font-serif font-bold text-lg text-sumi">Aa</span>
                </div>
                <span className="text-[10px] text-usuzumi">Text</span>
             </div>
             <span className="text-xl text-sumi/30">+</span>
             <div className="flex flex-col items-center gap-2">
                <div className="w-10 h-10 bg-white rounded border border-sumi/10 flex items-center justify-center shadow-sm">
                   <ImageIcon className="w-5 h-5 text-indigo-500" />
                </div>
                <span className="text-[10px] text-usuzumi">Image</span>
             </div>
             <span className="text-xl text-sumi/30">+</span>
             <div className="flex flex-col items-center gap-2">
                <div className="w-10 h-10 bg-white rounded border border-sumi/10 flex items-center justify-center shadow-sm">
                   <MessageCircle className="w-5 h-5 text-emerald-500" />
                </div>
                <span className="text-[10px] text-usuzumi">Audio</span>
             </div>
             
             <div className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/2">
                {/* Arrow */}
             </div>
          </div>
        </div>

        <div className="text-center mt-2">
           <p className="text-xs text-usuzumi font-serif italic">
             "Complexity requires modularity."
           </p>
        </div>
      </div>
    </SlideLayout>
  );
};