import React from 'react';
import { SlideLayout } from '../components/SlideLayout';
import { motion } from 'framer-motion';

export const AgendaSlide: React.FC = () => {
  const items = [
    "AIの進化と歴史",
    "RAG (Retrieval-Augmented Generation) とは",
    "[プロジェクト情報検索] 案件紹介",
    "質疑応答"
  ];

  return (
    <SlideLayout>
      <div className="h-full flex flex-col justify-center max-w-3xl mx-auto w-full">
        <div className="mb-16 border-l-4 border-kurenai pl-6">
          <h2 className="text-4xl font-serif font-bold text-sumi mb-2">目次</h2>
          <p className="text-usuzumi font-serif tracking-widest">AGENDA</p>
        </div>

        <ul className="space-y-8">
          {items.map((item, index) => (
            <motion.li 
              key={index}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 + index * 0.1, duration: 0.5 }}
              className="flex items-center group cursor-default"
            >
              <span className="text-kurenai font-serif font-bold text-2xl mr-6 opacity-60 group-hover:opacity-100 transition-opacity">
                0{index + 1}
              </span>
              <div className="h-px w-8 bg-sumi/20 mr-6"></div>
              <span className="text-xl md:text-2xl font-serif text-sumi font-medium group-hover:translate-x-2 transition-transform duration-300">
                {item}
              </span>
            </motion.li>
          ))}
        </ul>
      </div>
    </SlideLayout>
  );
};