import React from 'react';
import { SlideLayout } from '../components/SlideLayout';

export const StartSlide: React.FC = () => {
  return (
    <SlideLayout className="justify-center items-center text-center">
      <div className="space-y-6">
        <span className="inline-block py-1 px-3 border border-sumi/20 rounded-full text-xs tracking-widest text-sumi/60 mb-4 font-serif">
          社内技術共有会
        </span>
        
        <h1 className="text-5xl md:text-7xl font-serif font-bold text-sumi leading-tight tracking-tight">
          生成AIと<br/>
          <span className="text-kurenai">RAG技術</span>の活用
        </h1>
        
        <div className="w-16 h-1 bg-kurenai mx-auto my-8"></div>
        
        <h2 className="text-xl text-sumi/80 font-serif tracking-widest">
          プロジェクト情報検索システムの紹介
        </h2>
      </div>

      <div className="absolute bottom-12 text-sm text-usuzumi tracking-widest font-serif">
        2025年度・生産技術部
      </div>
    </SlideLayout>
  );
};