import React from 'react';
import { SlideLayout } from '../components/SlideLayout';
import { motion } from 'framer-motion';

export const ProjectFlowSlide: React.FC = () => {
  return (
    <SlideLayout>
      <div className="mb-4 border-l-4 border-kurenai pl-6">
        <h2 className="text-3xl font-serif font-bold text-sumi mb-1">システム処理フロー図</h2>
        <p className="text-usuzumi font-serif text-sm">Flowchart: Context Retrieval & Summarization</p>
      </div>

      <div className="flex-1 w-full h-full flex items-center justify-center">
        <svg viewBox="0 0 800 450" className="w-full h-full max-h-[80vh] drop-shadow-md font-serif">
          <defs>
            <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
              <polygon points="0 0, 10 3.5, 0 7" fill="#a63737" />
            </marker>
          </defs>

          {/* Background Zones */}
          <rect x="50" y="50" width="200" height="350" rx="10" fill="#f9f8f6" stroke="#e5e5e5" strokeDasharray="5,5" />
          <text x="150" y="80" textAnchor="middle" fill="#9ca3af" fontSize="12" letterSpacing="2">USER / WEB</text>

          <rect x="280" y="50" width="240" height="350" rx="10" fill="#f9f8f6" stroke="#e5e5e5" strokeDasharray="5,5" />
          <text x="400" y="80" textAnchor="middle" fill="#9ca3af" fontSize="12" letterSpacing="2">BACKEND & DB</text>

          <rect x="550" y="50" width="200" height="350" rx="10" fill="#f9f8f6" stroke="#e5e5e5" strokeDasharray="5,5" />
          <text x="650" y="80" textAnchor="middle" fill="#9ca3af" fontSize="12" letterSpacing="2">GEN AI (LLM)</text>

          {/* 1. User Input */}
          <g transform="translate(150, 150)">
             <circle cx="0" cy="0" r="20" fill="#2d2d2d" />
             <path d="M-10 5 Q0 15 10 5" stroke="white" strokeWidth="2" fill="none" />
             <circle cx="-7" cy="-5" r="2" fill="white" />
             <circle cx="7" cy="-5" r="2" fill="white" />
             <text x="0" y="40" textAnchor="middle" fontSize="14" fontWeight="bold" fill="#2d2d2d">ユーザー</text>
             
             {/* Speech Bubble */}
             <path d="M25 -30 L100 -30 L100 10 L40 10 L25 25 L25 -30" fill="white" stroke="#2d2d2d" strokeWidth="1" />
             <text x="35" y="-15" fontSize="10" fill="#2d2d2d">「計画書Aの</text>
             <text x="35" y="-2" fontSize="10" fill="#2d2d2d">指摘を教えて」</text>
          </g>

          {/* Arrow 1 */}
          <line x1="220" y1="150" x2="310" y2="150" stroke="#a63737" strokeWidth="2" markerEnd="url(#arrowhead)" />

          {/* 2. Database Retrieval Logic */}
          <g transform="translate(400, 150)">
             <path d="M-40 -30 L40 -30 L40 90 L-40 90 Z" fill="white" stroke="#2d2d2d" strokeWidth="2" />
             <path d="M-40 -30 L40 -30 L20 -50 L-60 -50 Z" fill="#e5e5e5" stroke="#2d2d2d" strokeWidth="1" />
             <text x="-50" y="-60" fontSize="12" fontWeight="bold" fill="#2d2d2d">pgvector</text>

             {/* Internal Structure */}
             <rect x="-30" y="-10" width="60" height="20" fill="#a63737" rx="2" />
             <text x="0" y="5" textAnchor="middle" fontSize="10" fill="white">計画書 A</text>
             
             {/* Connections */}
             <path d="M0 10 L-25 40" stroke="#9ca3af" strokeWidth="1" />
             <path d="M0 10 L0 40" stroke="#9ca3af" strokeWidth="1" />
             <path d="M0 10 L25 40" stroke="#9ca3af" strokeWidth="1" />

             {/* Minutes */}
             <rect x="-35" y="40" width="20" height="25" fill="white" stroke="#2d2d2d" />
             <text x="-25" y="55" textAnchor="middle" fontSize="8">議事録1</text>
             <rect x="-10" y="40" width="20" height="25" fill="white" stroke="#2d2d2d" />
             <text x="0" y="55" textAnchor="middle" fontSize="8">2</text>
             <rect x="15" y="40" width="20" height="25" fill="white" stroke="#2d2d2d" />
             <text x="25" y="55" textAnchor="middle" fontSize="8">3</text>
          </g>
          
          <text x="400" y="270" textAnchor="middle" fontSize="11" fill="#a63737" fontWeight="bold">関連議事録を全て抽出</text>

          {/* Arrow 2 */}
          <line x1="450" y1="180" x2="570" y2="180" stroke="#a63737" strokeWidth="2" markerEnd="url(#arrowhead)" />
          
          {/* Payload Label */}
          <rect x="470" y="165" width="80" height="16" fill="#f9f8f6" />
          <text x="510" y="177" textAnchor="middle" fontSize="9" fill="#a63737">全文コンテキスト</text>

          {/* 3. LLM Processing */}
          <g transform="translate(650, 180)">
             <path d="M-30 -20 Q0 -40 30 -20 Q40 0 30 20 Q0 40 -30 20 Q-40 0 -30 -20" fill="url(#grad1)" stroke="#a63737" strokeWidth="2" />
             <defs>
               <radialGradient id="grad1" cx="50%" cy="50%" r="50%" fx="50%" fy="50%">
                 <stop offset="0%" style={{stopColor:'white', stopOpacity:1}} />
                 <stop offset="100%" style={{stopColor:'#fecaca', stopOpacity:1}} />
               </radialGradient>
             </defs>
             <text x="0" y="5" textAnchor="middle" fontSize="14" fontWeight="bold" fill="#a63737">AI</text>
             
             {/* Sparkles */}
             <text x="25" y="-20" fontSize="16" fill="#a63737">✦</text>
             <text x="-35" y="25" fontSize="12" fill="#a63737">✦</text>
          </g>

          {/* Arrow 3 (Return) */}
          <path d="M650 210 Q650 350 200 350 L150 200" stroke="#2d2d2d" strokeWidth="2" fill="none" strokeDasharray="4" markerEnd="url(#arrowhead)" />

          {/* Result Doc */}
          <g transform="translate(180, 260)">
             <rect x="-40" y="-30" width="80" height="100" fill="white" stroke="#2d2d2d" strokeWidth="2" />
             <line x1="-30" y1="-15" x2="30" y2="-15" stroke="#a63737" strokeWidth="2" />
             <text x="0" y="0" textAnchor="middle" fontSize="12" fontWeight="bold" fill="#2d2d2d">指摘一覧</text>
             
             <line x1="-30" y1="20" x2="10" y2="20" stroke="#9ca3af" strokeWidth="2" />
             <line x1="-30" y1="35" x2="20" y2="35" stroke="#9ca3af" strokeWidth="2" />
             <line x1="-30" y1="50" x2="0" y2="50" stroke="#9ca3af" strokeWidth="2" />
             
             <circle cx="25" cy="50" r="15" fill="#a63737" />
             <path d="M18 50 L22 54 L32 44" stroke="white" strokeWidth="2" fill="none" />
          </g>

          <text x="420" y="370" textAnchor="middle" fontSize="12" fill="#2d2d2d" fontStyle="italic">要約・リスト化された回答</text>

        </svg>
      </div>
    </SlideLayout>
  );
};