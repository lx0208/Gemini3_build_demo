import React from 'react';
import { SlideLayout } from '../components/SlideLayout';
import { Code2, Server, BrainCircuit, Globe2 } from 'lucide-react';

export const TechStackSlide: React.FC = () => {
  return (
    <SlideLayout>
      <div className="mb-10 border-l-4 border-kurenai pl-6">
        <h2 className="text-3xl font-serif font-bold text-sumi mb-2">採用技術スタック</h2>
        <p className="text-usuzumi font-serif">Technology Stack</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 h-full content-center">
        {/* Frontend */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-sumi/5 flex items-start gap-4 hover:border-kurenai/30 transition-colors">
          <div className="bg-blue-50 p-3 rounded-full shrink-0">
            <Code2 className="w-8 h-8 text-[#61DAFB]" />
          </div>
          <div>
            <span className="text-xs font-bold text-usuzumi tracking-widest block mb-1">FRONTEND</span>
            <h3 className="text-xl font-bold font-serif text-sumi mb-2">React</h3>
            <p className="text-sm text-sumi/70 font-serif leading-relaxed">
              インタラクティブで高速なユーザーインターフェースを構築。
              モダンなコンポーネント設計により、保守性と拡張性を確保。
            </p>
          </div>
        </div>

        {/* Backend */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-sumi/5 flex items-start gap-4 hover:border-kurenai/30 transition-colors">
          <div className="bg-teal-50 p-3 rounded-full shrink-0">
            <Server className="w-8 h-8 text-[#009688]" />
          </div>
          <div>
            <span className="text-xs font-bold text-usuzumi tracking-widest block mb-1">BACKEND</span>
            <h3 className="text-xl font-bold font-serif text-sumi mb-2">FastAPI + LangChain</h3>
            <p className="text-sm text-sumi/70 font-serif leading-relaxed">
              <span className="font-bold">FastAPI</span>: 高速な非同期処理によるAPIサーバー。<br/>
              <span className="font-bold">LangChain</span>: LLMアプリケーション開発のためのフレームワーク。RAGフローの構築を効率化。
            </p>
          </div>
        </div>

        {/* LLM */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-sumi/5 flex items-start gap-4 hover:border-kurenai/30 transition-colors">
          <div className="bg-purple-50 p-3 rounded-full shrink-0">
            <BrainCircuit className="w-8 h-8 text-[#6c5ce7]" />
          </div>
          <div>
            <span className="text-xs font-bold text-usuzumi tracking-widest block mb-1">LLM (MODEL)</span>
            <h3 className="text-xl font-bold font-serif text-sumi mb-2">Cohere</h3>
            <p className="text-sm text-sumi/70 font-serif leading-relaxed">
              エンタープライズ向けの高性能言語モデルを採用。
              要約生成や複雑な指示の理解において高い精度を発揮。
            </p>
          </div>
        </div>

        {/* Embedding */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-sumi/5 flex items-start gap-4 hover:border-kurenai/30 transition-colors">
          <div className="bg-orange-50 p-3 rounded-full shrink-0">
            <Globe2 className="w-8 h-8 text-[#e17055]" />
          </div>
          <div>
            <span className="text-xs font-bold text-usuzumi tracking-widest block mb-1">EMBEDDING</span>
            <h3 className="text-xl font-bold font-serif text-sumi mb-2">Cohere Multilingual</h3>
            <p className="text-sm text-sumi/70 font-serif leading-relaxed">
              多言語対応のEmbeddingモデル。<br/>
              日本語の意味的ニュアンスを正確にベクトル化し、高精度な検索を実現。
            </p>
          </div>
        </div>
      </div>
    </SlideLayout>
  );
};