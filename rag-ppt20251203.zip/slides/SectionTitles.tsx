import React from 'react';
import { SlideLayout } from '../components/SlideLayout';
import { motion } from 'framer-motion';

interface TitleProps {
  number: string;
  title: string;
  subtitle: string;
}

const SectionTitle: React.FC<TitleProps> = ({ number, title, subtitle }) => {
  return (
    <SlideLayout className="justify-center items-center text-center">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
        className="relative z-10"
      >
        <div className="flex flex-col items-center gap-4">
            <span className="text-kurenai font-serif font-bold text-xl tracking-[0.2em] border-b border-kurenai pb-1">
                SECTION {number}
            </span>
            <h2 className="text-5xl md:text-7xl font-serif font-bold text-sumi leading-tight mt-4 mb-6">
                {title}
            </h2>
            <p className="text-usuzumi font-serif text-lg tracking-wider">
                {subtitle}
            </p>
        </div>
      </motion.div>
      
      {/* Dynamic Background Element */}
      <motion.div 
        initial={{ width: "0%" }}
        animate={{ width: "100%" }}
        transition={{ duration: 1, ease: "circOut" }}
        className="absolute bottom-0 left-0 h-2 bg-gradient-to-r from-kurenai/0 via-kurenai/20 to-kurenai/0"
      />
    </SlideLayout>
  );
};

export const HistoryTitleSlide = () => (
  <SectionTitle number="01" title="AIの進化と歴史" subtitle="The Evolution of Artificial Intelligence" />
);

export const RagTitleSlide = () => (
  <SectionTitle number="02" title="RAG とは" subtitle="Retrieval-Augmented Generation" />
);

export const ProjectTitleSlide = () => (
  <SectionTitle number="03" title="案件紹介" subtitle="Project: Information Retrieval System" />
);

export const QATitleSlide = () => (
  <SectionTitle number="04" title="質疑応答" subtitle="Questions & Answers" />
);