import React from 'react';
import { SlideLayout } from '../components/SlideLayout';

export const RagIntroSlide: React.FC = () => {
  return (
    <SlideLayout>
      <div className="mb-8 border-l-4 border-kurenai pl-6">
        <h2 className="text-3xl font-serif font-bold text-sumi mb-2">RAG (Retrieval-Augmented Generation) とは</h2>
        <p className="text-usuzumi font-serif">外部知識を活用した生成AIの仕組み</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 h-full">
        {/* Left: Text Content */}
        <div className="space-y-6 flex flex-col justify-center">
          <div className="bg-white p-5 rounded shadow-sm border border-sumi/5 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-1 h-full bg-usuzumi/30"></div>
            <h3 className="text-lg font-bold font-serif mb-2 text-usuzumi">従来の LLM の課題</h3>
            <ul className="space-y-2 text-sm font-serif text-sumi/80 list-disc list-inside">
              <li>最新の情報を知らない (学習データのカットオフ)</li>
              <li>社内固有の機密情報を知らない</li>
              <li>「ハルシネーション」(もっともらしい嘘) の発生</li>
            </ul>
          </div>

          <div className="flex justify-center my-2">
            <span className="text-kurenai font-serif text-xl italic font-bold">⬇︎ 解決策 ⬇︎</span>
          </div>

          <div className="bg-white p-5 rounded shadow-lg border-t-2 border-kurenai">
            <h3 className="text-lg font-bold font-serif mb-2 text-kurenai">RAG のメリット</h3>
            <ul className="space-y-2 text-sm font-serif text-sumi/80 list-disc list-inside">
              <li>社内データベースに基づいた正確な回答</li>
              <li>根拠(ソース)の提示が可能</li>
              <li>再学習なしで最新情報を反映</li>
            </ul>
          </div>
        </div>

        {/* Right: SVG Diagram */}
        <div className="w-full h-full min-h-[300px] flex items-center justify-center bg-white/50 rounded-xl border border-sumi/5 p-4">
          <svg viewBox="0 0 500 400" className="w-full h-full drop-shadow-sm font-serif">
            <defs>
              <marker id="arrowHead" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
                <polygon points="0 0, 10 3.5, 0 7" fill="#2d2d2d" />
              </marker>
              <marker id="arrowHeadRed" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
                <polygon points="0 0, 10 3.5, 0 7" fill="#a63737" />
              </marker>
            </defs>

            {/* --- 1. Knowledge Base (Bottom Left) --- */}
            <g transform="translate(50, 280)">
               <text x="0" y="-40" fontSize="12" fill="#9ca3af" fontWeight="bold">1. 知識の蓄積</text>
               {/* Docs Icons */}
               <path d="M-20 -20 L10 -20 L10 20 L-20 20 Z" fill="white" stroke="#2d2d2d" strokeWidth="1" />
               <path d="M-15 -15 L15 -15 L15 25 L-15 25 Z" fill="white" stroke="#2d2d2d" strokeWidth="1" />
               <line x1="-10" y1="-5" x2="10" y2="-5" stroke="#usuzumi" strokeWidth="1"/>
               <line x1="-10" y1="5" x2="10" y2="5" stroke="#usuzumi" strokeWidth="1"/>
               <line x1="-10" y1="15" x2="5" y2="15" stroke="#usuzumi" strokeWidth="1"/>
               <text x="0" y="40" textAnchor="middle" fontSize="10" fill="#2d2d2d">社内文書</text>
               
               {/* Arrow to DB */}
               <line x1="30" y1="5" x2="60" y2="5" stroke="#2d2d2d" strokeWidth="1" markerEnd="url(#arrowHead)" strokeDasharray="3,3"/>
               
               {/* Vector DB */}
               <g transform="translate(90, 0)">
                 <path d="M-20 -25 L20 -25 L20 25 L-20 25 Z" fill="#2d2d2d" stroke="#2d2d2d" />
                 <path d="M-20 -25 L20 -25 L10 -35 L-30 -35 Z" fill="#555" />
                 <path d="M20 -25 L20 25 L10 15 L10 -35" fill="#444" />
                 <text x="0" y="5" textAnchor="middle" fontSize="10" fill="white" fontWeight="bold">Vector</text>
                 <text x="0" y="17" textAnchor="middle" fontSize="10" fill="white" fontWeight="bold">DB</text>
               </g>
            </g>

            {/* --- 2. User Query (Top Left) --- */}
            <g transform="translate(60, 80)">
              <circle cx="0" cy="0" r="15" fill="#f9f8f6" stroke="#2d2d2d" strokeWidth="2" />
              <path d="M-7 5 Q0 12 7 5" stroke="#2d2d2d" fill="none" />
              <circle cx="-5" cy="-3" r="1.5" fill="#2d2d2d" />
              <circle cx="5" cy="-3" r="1.5" fill="#2d2d2d" />
              <text x="0" y="30" textAnchor="middle" fontSize="12" fontWeight="bold" fill="#2d2d2d">User</text>
              
              {/* Question Bubble */}
              <g transform="translate(40, -10)">
                <path d="M0 0 L100 0 L100 30 L20 30 L0 40 Z" fill="#a63737" stroke="none" opacity="0.1" />
                <rect x="0" y="0" width="100" height="30" fill="none" stroke="#a63737" strokeWidth="1" />
                <text x="50" y="20" textAnchor="middle" fontSize="11" fill="#a63737" fontWeight="bold">質問 (Query)</text>
              </g>
            </g>

            {/* --- 3. Retrieval Flow (Middle) --- */}
            
            {/* Arrow: Query -> Retrieval */}
            <path d="M160 85 L200 85 L200 130" stroke="#a63737" strokeWidth="2" fill="none" markerEnd="url(#arrowHeadRed)" />
            
            {/* Arrow: Query -> Retrieval (Search in DB) */}
            <path d="M200 130 L160 260" stroke="#a63737" strokeWidth="2" fill="none" markerEnd="url(#arrowHeadRed)" strokeDasharray="4"/>
            <text x="170" y="200" fontSize="10" fill="#a63737" transform="rotate(-72 170 200)">2. 検索</text>

            {/* Arrow: DB -> Context */}
            <path d="M160 270 L240 160" stroke="#a63737" strokeWidth="2" fill="none" markerEnd="url(#arrowHeadRed)" />
            <rect x="200" y="205" width="60" height="16" fill="white" stroke="#a63737" strokeWidth="1" rx="4" transform="rotate(-54 230 213)"/>
            <text x="230" y="217" textAnchor="middle" fontSize="9" fill="#a63737" transform="rotate(-54 230 213)">3. 関連情報</text>

            {/* --- 4. LLM Generation (Right) --- */}
            <g transform="translate(320, 150)">
              {/* Prompt Box */}
              <rect x="-40" y="-40" width="80" height="80" rx="8" fill="white" stroke="#2d2d2d" strokeWidth="2" strokeDasharray="2,2"/>
              <text x="0" y="-20" textAnchor="middle" fontSize="10" fill="#2d2d2d">プロンプト</text>
              <line x1="-30" y1="-10" x2="30" y2="-10" stroke="#2d2d2d" strokeWidth="1" opacity="0.2"/>
              <text x="0" y="5" textAnchor="middle" fontSize="9" fill="#a63737">質問</text>
              <text x="0" y="15" textAnchor="middle" fontSize="9" fill="#2d2d2d">+</text>
              <text x="0" y="25" textAnchor="middle" fontSize="9" fill="#a63737" fontWeight="bold">関連情報</text>

              {/* Arrow to LLM */}
              <line x1="40" y1="0" x2="70" y2="0" stroke="#2d2d2d" strokeWidth="2" markerEnd="url(#arrowHead)" />
            </g>

            {/* LLM Core */}
            <g transform="translate(420, 150)">
              <circle cx="0" cy="0" r="30" fill="#2d2d2d" />
              <path d="M-15 -5 L0 -20 L15 -5 L0 10 Z" fill="none" stroke="#a63737" strokeWidth="2" />
              <path d="M-15 5 L0 20 L15 5 L0 -10 Z" fill="none" stroke="white" strokeWidth="1" />
              <text x="0" y="45" textAnchor="middle" fontSize="12" fontWeight="bold" fill="#2d2d2d">LLM</text>
            </g>

            {/* --- 5. Output (Far Right / Bottom) --- */}
            <path d="M420 180 L420 230 L380 230" stroke="#2d2d2d" strokeWidth="2" fill="none" markerEnd="url(#arrowHead)" />
            
            <g transform="translate(300, 215)">
              <path d="M0 0 L-10 15 L-10 45 L70 45 L70 15 L10 0 Z" fill="white" stroke="#2d2d2d" strokeWidth="2" />
              <text x="30" y="25" textAnchor="middle" fontSize="12" fontWeight="bold" fill="#2d2d2d">4. 回答生成</text>
              <text x="30" y="38" textAnchor="middle" fontSize="9" fill="#usuzumi">根拠に基づいた答え</text>
            </g>

          </svg>
        </div>
      </div>
    </SlideLayout>
  );
};
