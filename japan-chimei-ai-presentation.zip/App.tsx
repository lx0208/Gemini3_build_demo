import React, { useState, useEffect, useCallback } from 'react';
import { AnimatePresence } from 'framer-motion';
import { Header } from './components/Header';
import { StartSlide } from './slides/StartSlide';
import { HistorySlide } from './slides/HistorySlide';
import { RagIntroSlide } from './slides/RagIntroSlide';
import { ProjectLogicSlide } from './slides/ProjectLogicSlide';
import { ProjectFlowSlide } from './slides/ProjectFlowSlide';
import { EndSlide } from './slides/EndSlide';
import { ChevronLeft, ChevronRight } from 'lucide-react';

const slides = [
  StartSlide,
  HistorySlide,
  RagIntroSlide,
  ProjectLogicSlide,
  ProjectFlowSlide,
  EndSlide
];

const App: React.FC = () => {
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);

  const nextSlide = useCallback(() => {
    setCurrentSlideIndex((prev) => Math.min(prev + 1, slides.length - 1));
  }, []);

  const prevSlide = useCallback(() => {
    setCurrentSlideIndex((prev) => Math.max(prev - 1, 0));
  }, []);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight' || e.key === 'ArrowDown' || e.key === 'Space') {
        nextSlide();
      } else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
        prevSlide();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [nextSlide, prevSlide]);

  const CurrentSlideComponent = slides[currentSlideIndex];

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#f9f8f6] text-[#2d2d2d] selection:bg-kurenai/20">
      
      <Header />

      <main className="w-full h-full pt-20 relative z-10">
        <AnimatePresence mode="wait">
          <CurrentSlideComponent key={currentSlideIndex} />
        </AnimatePresence>
      </main>

      {/* Navigation Controls (Visible on hover or mobile) */}
      <div className="fixed bottom-6 right-8 flex items-center gap-4 z-50">
        <button 
          onClick={prevSlide}
          disabled={currentSlideIndex === 0}
          className="p-3 rounded-full bg-white/80 hover:bg-white text-sumi shadow-sm disabled:opacity-30 border border-sumi/10 transition-all hover:scale-110 active:scale-95"
          aria-label="Previous Slide"
        >
          <ChevronLeft size={20} />
        </button>
        
        <span className="font-serif text-sm tracking-widest text-sumi/60">
          {currentSlideIndex + 1} <span className="text-xs mx-1">/</span> {slides.length}
        </span>

        <button 
          onClick={nextSlide}
          disabled={currentSlideIndex === slides.length - 1}
          className="p-3 rounded-full bg-sumi hover:bg-sumi/90 text-white shadow-lg disabled:opacity-30 disabled:bg-sumi transition-all hover:scale-110 active:scale-95"
          aria-label="Next Slide"
        >
          <ChevronRight size={20} />
        </button>
      </div>

      {/* Background Texture Overlay (Subtle noise/paper effect) */}
      <div className="fixed inset-0 pointer-events-none opacity-[0.03] z-0" 
           style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")` }}>
      </div>
    </div>
  );
};

export default App;