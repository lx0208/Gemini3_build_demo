import React from 'react';
import { SlideLayout } from '../components/SlideLayout';

export const EndSlide: React.FC = () => {
  return (
    <SlideLayout className="justify-center items-center text-center">
      <div className="relative">
        <h1 className="text-4xl md:text-5xl font-serif font-bold text-sumi mb-12 tracking-widest">
          ご清聴<br />ありがとうございました
        </h1>
        
        {/* Decorative circle */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 border border-sumi/10 rounded-full -z-10 animate-[spin_60s_linear_infinite]"></div>
      </div>

      <div className="bg-white px-8 py-6 shadow-sm border-t-4 border-kurenai max-w-lg w-full">
        <h3 className="text-lg font-bold font-serif text-sumi mb-4">質疑応答 (Q&A)</h3>
        <p className="text-sm text-usuzumi font-serif">
          本システムやRAG技術に関するご質問がございましたら、<br/>
          お気軽にお尋ねください。
        </p>
      </div>

      <div className="absolute bottom-12 flex flex-col items-center gap-2">
        <span className="text-xs font-sans tracking-[0.3em] text-kurenai">PROJECT INFORMATION SEARCH</span>
        <span className="text-sm font-serif font-bold text-sumi">日本智明 - 生産技術部</span>
      </div>
    </SlideLayout>
  );
};