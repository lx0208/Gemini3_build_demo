import React from 'react';
import { SlideLayout } from '../components/SlideLayout';
import { FileSearch, ArrowDown, FileStack, Sparkles } from 'lucide-react';

export const ProjectLogicSlide: React.FC = () => {
  return (
    <SlideLayout>
      <div className="mb-8 border-l-4 border-kurenai pl-6">
        <h2 className="text-3xl font-serif font-bold text-sumi mb-2">プロジェクト情報検索システム</h2>
        <p className="text-usuzumi font-serif">Webチャット × pgvector による指摘事項抽出</p>
      </div>

      <div className="flex flex-col md:flex-row gap-8 h-full">
        {/* Logic Flow Column */}
        <div className="flex-1 space-y-6">
          <div className="flex items-start gap-4 p-4 bg-white rounded border-l-2 border-sumi shadow-sm">
            <div className="bg-stone-100 p-2 rounded">
               <FileSearch className="text-sumi w-6 h-6" />
            </div>
            <div>
               <h4 className="font-bold font-serif text-sumi">1. ユーザーの要求</h4>
               <p className="text-sm text-sumi/70 mt-1 font-serif">特定の「プロジェクト計画書」に対する指摘を知りたい。</p>
            </div>
          </div>

          <div className="flex justify-center">
             <ArrowDown className="text-usuzumi w-5 h-5 animate-bounce" />
          </div>

          <div className="flex items-start gap-4 p-4 bg-white rounded border-l-2 border-usuzumi shadow-sm">
            <div className="bg-stone-100 p-2 rounded">
               <FileStack className="text-sumi w-6 h-6" />
            </div>
            <div>
               <h4 className="font-bold font-serif text-sumi">2. 関連文書の網羅的検索</h4>
               <p className="text-sm text-sumi/70 mt-1 font-serif">
                 <span className="font-sans font-bold text-kurenai">pgvector</span> を使用し、
                 対象の計画書に紐づく<br/>
                 <span className="font-bold underline decoration-kurenai/30 underline-offset-4">全ての「議事録」</span>を抽出。
               </p>
            </div>
          </div>

          <div className="flex justify-center">
             <ArrowDown className="text-usuzumi w-5 h-5 animate-bounce" />
          </div>

          <div className="flex items-start gap-4 p-4 bg-white rounded border-l-2 border-kurenai shadow-sm bg-gradient-to-r from-red-50/50 to-transparent">
            <div className="bg-kurenai/10 p-2 rounded">
               <Sparkles className="text-kurenai w-6 h-6" />
            </div>
            <div>
               <h4 className="font-bold font-serif text-sumi">3. AIによる指摘一覧生成</h4>
               <p className="text-sm text-sumi/70 mt-1 font-serif">
                 複数の議事録をLLMが解析し、指摘事項のみを要約してリスト化。
               </p>
            </div>
          </div>
        </div>

        {/* Data Structure Diagram */}
        <div className="w-full md:w-1/3 bg-stone-200/50 rounded-xl p-6 flex flex-col items-center justify-center relative border border-white/50">
            <h3 className="absolute top-4 left-6 text-sm font-bold font-serif text-sumi/50 tracking-widest">DATA STRUCTURE</h3>
            
            {/* Parent Node */}
            <div className="w-48 bg-sumi text-white p-3 rounded text-center shadow-lg mb-8 z-10 relative">
                <span className="font-serif font-bold text-sm">プロジェクト計画書</span>
                <div className="absolute -bottom-8 left-1/2 w-0.5 h-8 bg-sumi/30 -translate-x-1/2"></div>
            </div>

            {/* Children Nodes */}
            <div className="grid grid-cols-3 gap-2 w-full relative">
                {/* Connecting lines */}
                <div className="absolute -top-4 left-1/2 w-[80%] h-4 border-t-2 border-l-2 border-r-2 border-sumi/30 rounded-t-lg -translate-x-1/2"></div>

                <div className="bg-white p-3 rounded text-center shadow border border-sumi/10">
                   <span className="text-xs font-serif text-sumi">議事録 A</span>
                </div>
                <div className="bg-white p-3 rounded text-center shadow border border-sumi/10">
                   <span className="text-xs font-serif text-sumi">議事録 B</span>
                </div>
                <div className="bg-white p-3 rounded text-center shadow border border-sumi/10">
                   <span className="text-xs font-serif text-sumi">議事録 C...</span>
                </div>
            </div>

            <div className="mt-8 p-4 bg-kurenai/5 border border-kurenai/20 rounded-lg w-full">
                <p className="text-xs text-center text-kurenai font-serif font-bold">
                    「1対多」の関係性を完全保持
                </p>
            </div>
        </div>
      </div>
    </SlideLayout>
  );
};