import React from 'react';
import { SlideLayout } from '../components/SlideLayout';
import { Database, BrainCircuit, FileText, MessageSquare } from 'lucide-react';
import { motion } from 'framer-motion';

export const RagIntroSlide: React.FC = () => {
  return (
    <SlideLayout>
      <div className="mb-12 border-l-4 border-kurenai pl-6">
        <h2 className="text-3xl font-serif font-bold text-sumi mb-2">RAG (Retrieval-Augmented Generation) とは</h2>
        <p className="text-usuzumi font-serif">外部知識を活用した生成AIの仕組み</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12 h-full items-center">
        {/* Left: The Problem */}
        <div className="space-y-8">
          <div className="bg-white p-6 rounded shadow-sm border border-sumi/5 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-1 h-full bg-usuzumi/30"></div>
            <h3 className="text-lg font-bold font-serif mb-3 text-usuzumi">従来の LLM の課題</h3>
            <ul className="space-y-3 text-sm font-serif text-sumi/80 list-disc list-inside">
              <li>最新の情報を知らない (学習データのカットオフ)</li>
              <li>社内固有の機密情報を知らない</li>
              <li>「ハルシネーション」(もっともらしい嘘) の発生</li>
            </ul>
          </div>

          <div className="flex justify-center">
            <span className="text-kurenai font-serif text-xl italic">解決策 → RAG</span>
          </div>

          <div className="bg-white p-6 rounded shadow-lg border-t-2 border-kurenai">
            <h3 className="text-lg font-bold font-serif mb-3 text-kurenai">RAG のメリット</h3>
            <ul className="space-y-3 text-sm font-serif text-sumi/80 list-disc list-inside">
              <li>社内データベースに基づいた正確な回答</li>
              <li>根拠(ソース)の提示が可能</li>
              <li>再学習なしで最新情報を反映</li>
            </ul>
          </div>
        </div>

        {/* Right: The Diagram */}
        <div className="relative h-80 bg-stone-100 rounded-lg p-6 flex flex-col justify-between items-center border border-dashed border-sumi/20">
            
            {/* Top: User */}
            <div className="flex items-center gap-4 w-full justify-center z-10">
                <div className="bg-white p-3 rounded-full shadow border border-sumi/10">
                    <MessageSquare size={24} className="text-sumi"/>
                </div>
                <div className="text-xs font-serif text-sumi">質問</div>
            </div>

            {/* Middle: RAG Engine */}
            <div className="flex w-full justify-between items-center px-4 z-10">
                 <div className="flex flex-col items-center gap-2">
                    <div className="bg-sumi p-3 rounded shadow text-white">
                        <Database size={24} />
                    </div>
                    <span className="text-[10px] font-sans font-bold uppercase tracking-wider text-sumi/70">Vector DB</span>
                    <span className="text-[10px] font-serif text-sumi/50">関連文書の検索</span>
                 </div>

                 <motion.div 
                    animate={{ x: [0, 10, 0] }}
                    transition={{ repeat: Infinity, duration: 2 }}
                    className="h-px bg-kurenai flex-1 mx-4 relative"
                 >
                    <div className="absolute -top-1.5 right-0 w-3 h-3 border-t border-r border-kurenai rotate-45"></div>
                 </motion.div>

                 <div className="flex flex-col items-center gap-2">
                    <div className="bg-kurenai p-3 rounded shadow text-white">
                        <BrainCircuit size={24} />
                    </div>
                    <span className="text-[10px] font-sans font-bold uppercase tracking-wider text-kurenai">LLM</span>
                    <span className="text-[10px] font-serif text-sumi/50">回答生成</span>
                 </div>
            </div>

            {/* Bottom: Context */}
            <div className="bg-white/80 p-4 w-full rounded border border-sumi/5 mt-4 z-10 text-center">
                <div className="flex justify-center gap-2 mb-2">
                    <FileText size={16} className="text-usuzumi"/>
                    <FileText size={16} className="text-usuzumi"/>
                </div>
                <p className="text-xs font-serif text-sumi/70">社内ナレッジ・マニュアル</p>
            </div>
            
            {/* Connection Lines (Decorative) */}
            <div className="absolute inset-0 flex justify-center items-center pointer-events-none">
                <div className="w-px h-full bg-sumi/5"></div>
            </div>
        </div>
      </div>
    </SlideLayout>
  );
};