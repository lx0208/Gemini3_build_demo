import React from 'react';
import { SlideLayout } from '../components/SlideLayout';
import { ArrowRight } from 'lucide-react';

const events = [
  { year: 'Early', title: 'ルールベース', sub: 'Rules', desc: '手動で定義された論理規則' },
  { year: '1980s', title: '機械学習', sub: 'Machine Learning', desc: 'データからのパターン学習' },
  { year: '2010s', title: '深層学習', sub: 'Deep Learning', desc: 'ニューラルネットワークの多層化' },
  { year: '2017', title: 'Transformer', sub: 'Attention Mechanism', desc: '自然言語処理の革命的ブレイクスルー' },
  { year: '2020s', title: '大規模言語モデル', sub: 'LLM / Multimodal', desc: '生成AIの台頭・マルチモーダル化' },
  { year: 'Future', title: 'AGI 雛形', sub: 'Artificial General Intelligence', desc: '汎用人工知能への道' },
];

export const HistorySlide: React.FC = () => {
  return (
    <SlideLayout>
      <div className="mb-12 border-l-4 border-kurenai pl-6">
        <h2 className="text-3xl font-serif font-bold text-sumi mb-2">AIの進化と歴史</h2>
        <p className="text-usuzumi font-serif">The Evolution of Artificial Intelligence</p>
      </div>

      <div className="flex-1 flex items-center justify-center overflow-x-auto">
        <div className="flex items-start gap-4 min-w-max px-4">
          {events.map((evt, idx) => (
            <div key={idx} className="flex items-start group">
              <div className="flex flex-col items-center gap-4 relative">
                {/* Connector Line */}
                {idx !== events.length - 1 && (
                  <div className="absolute top-3 left-[100%] w-full h-px bg-sumi/20 -z-10" style={{ width: 'calc(100% + 1rem)' }}></div>
                )}
                
                {/* Node */}
                <div className={`w-6 h-6 rounded-full border-2 z-10 bg-washi transition-colors duration-500 
                  ${idx >= 4 ? 'border-kurenai bg-kurenai' : 'border-sumi/30'}`} 
                />
                
                {/* Content */}
                <div className="w-40 text-center space-y-2 mt-4">
                  <span className="text-xs text-usuzumi font-sans">{evt.year}</span>
                  <h3 className="text-lg font-bold font-serif text-sumi">{evt.title}</h3>
                  <div className="text-xs text-kurenai font-sans font-semibold">{evt.sub}</div>
                  <p className="text-xs text-sumi/60 leading-relaxed font-serif">
                    {evt.desc}
                  </p>
                </div>
              </div>
              
              {idx !== events.length - 1 && (
                 <ArrowRight className="w-4 h-4 text-sumi/20 mt-4 mx-2 opacity-0" /> // Spacer
              )}
            </div>
          ))}
        </div>
      </div>
    </SlideLayout>
  );
};