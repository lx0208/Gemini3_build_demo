import React from 'react';
import { Logo } from './Logo';

export const Header: React.FC = () => {
  return (
    <header className="fixed top-0 left-0 w-full z-50 flex justify-between items-center px-8 py-6 mix-blend-multiply pointer-events-none">
      <div className="flex items-center gap-4">
        <Logo className="w-10 h-10 text-sumi" />
        <div className="h-8 w-px bg-sumi/30 mx-2"></div>
        <div className="flex flex-col font-serif">
          <span className="text-xs tracking-widest text-usuzumi uppercase">Japan Chimei</span>
          <span className="text-sm font-bold tracking-wider text-sumi">日本智明 - 生産技術部</span>
        </div>
      </div>
      
      <div className="text-[10px] text-usuzumi tracking-[0.2em] font-sans">
        AI TRANSFORMATION PROJECT
      </div>
    </header>
  );
};