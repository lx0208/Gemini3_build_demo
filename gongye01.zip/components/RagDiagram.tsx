import React, { useState } from 'react';
import { DiagramPart } from '../types';
import { Database, Brain, User, FileText } from 'lucide-react';

interface RagDiagramProps {
  activePart?: DiagramPart;
  onPartHover?: (part: DiagramPart) => void;
}

export const RagDiagram: React.FC<RagDiagramProps> = ({ activePart: externalActivePart, onPartHover }) => {
  const [internalActivePart, setInternalActivePart] = useState<DiagramPart>(DiagramPart.NONE);
  
  const currentPart = externalActivePart || internalActivePart;

  const handleEnter = (part: DiagramPart) => {
    setInternalActivePart(part);
    if (onPartHover) onPartHover(part);
  };

  const handleLeave = () => {
    setInternalActivePart(DiagramPart.NONE);
    if (onPartHover) onPartHover(DiagramPart.NONE);
  };

  const getOpacity = (part: DiagramPart) => {
    if (currentPart === DiagramPart.NONE) return 1;
    return currentPart === part ? 1 : 0.3;
  };

  const getStroke = (part: DiagramPart) => {
    return currentPart === part ? "#f97316" : "#27272a"; // Orange or Zinc-800
  };

  const getFill = (part: DiagramPart) => {
    return currentPart === part ? "#fff7ed" : "#ffffff"; // Very light orange or white
  };
  
  const getStrokeWidth = (part: DiagramPart) => {
      return currentPart === part ? "3" : "2";
  }

  const textColor = "#18181b"; // Zinc 900
  const subTextColor = "#52525b"; // Zinc 600

  return (
    <div className="w-full h-full flex flex-col items-center justify-center p-2 relative">
      <div className="absolute top-2 right-2 text-[10px] font-mono text-zinc-400 border border-zinc-300 px-1">FIG 1.0</div>
      <svg 
        viewBox="0 0 800 500" 
        className="w-full h-full font-mono"
        style={{ overflow: 'visible' }}
      >
        <defs>
          <marker id="arrowhead" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto">
            <path d="M0,0 L8,4 L0,8 Z" fill="#27272a" />
          </marker>
          <marker id="arrowhead-active" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto">
            <path d="M0,0 L8,4 L0,8 Z" fill="#f97316" />
          </marker>
        </defs>

        {/* --- 1. User & Query --- */}
        <g 
          transform="translate(50, 200)" 
          onMouseEnter={() => handleEnter(DiagramPart.USER)}
          onMouseLeave={handleLeave}
          style={{ cursor: 'pointer', opacity: getOpacity(DiagramPart.USER), transition: 'opacity 0.2s' }}
        >
          {/* Sharp corners for industrial look */}
          <rect x="-20" y="-40" width="120" height="130" fill={getFill(DiagramPart.USER)} stroke={getStroke(DiagramPart.USER)} strokeWidth={getStrokeWidth(DiagramPart.USER)} />
          <User className="text-zinc-800" x="20" y="-20" width="40" height="40" strokeWidth={2} />
          <text x="40" y="45" textAnchor="middle" fill={textColor} fontSize="16" fontWeight="700" style={{fontFamily: 'Oswald'}}>USER</text>
          <text x="40" y="70" textAnchor="middle" fill={subTextColor} fontSize="11" fontWeight="500" style={{fontFamily: 'JetBrains Mono'}}>INPUT</text>
        </g>

        {/* --- 2. Embedding Model --- */}
        <g 
          transform="translate(260, 100)" 
          onMouseEnter={() => handleEnter(DiagramPart.EMBEDDING)}
          onMouseLeave={handleLeave}
          style={{ cursor: 'pointer', opacity: getOpacity(DiagramPart.EMBEDDING), transition: 'opacity 0.2s' }}
        >
          {/* Hexagon or Circle with crosshair */}
          <circle cx="0" cy="0" r="60" fill={getFill(DiagramPart.EMBEDDING)} stroke={getStroke(DiagramPart.EMBEDDING)} strokeWidth={getStrokeWidth(DiagramPart.EMBEDDING)} />
          <Brain x="-25" y="-30" width="50" height="50" color="#27272a" strokeWidth={1.5} />
          <text x="0" y="85" textAnchor="middle" fill={textColor} fontSize="16" fontWeight="700" style={{fontFamily: 'Oswald'}}>EMBEDDING</text>
          <text x="0" y="105" textAnchor="middle" fill={subTextColor} fontSize="11" fontWeight="500" style={{fontFamily: 'JetBrains Mono'}}>VECTORIZE</text>
        </g>

        {/* --- 3. Vector DB --- */}
        <g 
          transform="translate(480, 100)" 
          onMouseEnter={() => handleEnter(DiagramPart.VECTOR_DB)}
          onMouseLeave={handleLeave}
          style={{ cursor: 'pointer', opacity: getOpacity(DiagramPart.VECTOR_DB), transition: 'opacity 0.2s' }}
        >
          {/* Cylinder stylized */}
          <path d="M-50,-40 L50,-40 L50,40 L-50,40 Z" fill={getFill(DiagramPart.VECTOR_DB)} stroke={getStroke(DiagramPart.VECTOR_DB)} strokeWidth={getStrokeWidth(DiagramPart.VECTOR_DB)} />
          <line x1="-50" y1="-40" x2="50" y2="-40" stroke={getStroke(DiagramPart.VECTOR_DB)} strokeWidth="2" />
          <line x1="-50" y1="40" x2="50" y2="40" stroke={getStroke(DiagramPart.VECTOR_DB)} strokeWidth="2" />
          
          {/* Interior lines to suggest stack */}
          <line x1="-50" y1="-15" x2="50" y2="-15" stroke={getStroke(DiagramPart.VECTOR_DB)} strokeWidth="1" strokeDasharray="4 2" />
          <line x1="-50" y1="15" x2="50" y2="15" stroke={getStroke(DiagramPart.VECTOR_DB)} strokeWidth="1" strokeDasharray="4 2" />

          <Database x="-20" y="-20" width="40" height="40" color="#27272a" strokeWidth={1.5} />
          <text x="0" y="75" textAnchor="middle" fill={textColor} fontSize="16" fontWeight="700" style={{fontFamily: 'Oswald'}}>VECTOR DB</text>
          <text x="0" y="95" textAnchor="middle" fill={subTextColor} fontSize="11" fontWeight="500" style={{fontFamily: 'JetBrains Mono'}}>KNOWLEDGE</text>
        </g>

        {/* --- 4. Context Construction --- */}
        <g 
          transform="translate(480, 320)" 
          onMouseEnter={() => handleEnter(DiagramPart.CONTEXT)}
          onMouseLeave={handleLeave}
          style={{ cursor: 'pointer', opacity: getOpacity(DiagramPart.CONTEXT), transition: 'opacity 0.2s' }}
        >
          {/* Sharp rect with dash */}
          <rect x="-70" y="-50" width="140" height="100" fill={getFill(DiagramPart.CONTEXT)} stroke={getStroke(DiagramPart.CONTEXT)} strokeWidth={getStrokeWidth(DiagramPart.CONTEXT)} strokeDasharray="8,4" />
          <FileText x="-20" y="-25" width="40" height="40" color="#27272a" strokeWidth={1.5} />
          <text x="0" y="75" textAnchor="middle" fill={textColor} fontSize="16" fontWeight="700" style={{fontFamily: 'Oswald'}}>CONTEXT</text>
          <text x="0" y="95" textAnchor="middle" fill={subTextColor} fontSize="11" fontWeight="500" style={{fontFamily: 'JetBrains Mono'}}>PROMPT</text>
        </g>

        {/* --- 5. LLM --- */}
        <g 
          transform="translate(680, 200)" 
          onMouseEnter={() => handleEnter(DiagramPart.LLM)}
          onMouseLeave={handleLeave}
          style={{ cursor: 'pointer', opacity: getOpacity(DiagramPart.LLM), transition: 'opacity 0.2s' }}
        >
          {/* Chip style */}
          <rect x="-60" y="-60" width="120" height="120" fill={getFill(DiagramPart.LLM)} stroke={getStroke(DiagramPart.LLM)} strokeWidth={getStrokeWidth(DiagramPart.LLM)} />
          {/* Chip pins */}
          <rect x="-65" y="-50" width="5" height="10" fill="#27272a" />
          <rect x="-65" y="-30" width="5" height="10" fill="#27272a" />
          <rect x="-65" y="-10" width="5" height="10" fill="#27272a" />
          
          <rect x="60" y="-50" width="5" height="10" fill="#27272a" />
          <rect x="60" y="-30" width="5" height="10" fill="#27272a" />
          <rect x="60" y="-10" width="5" height="10" fill="#27272a" />

          <Brain x="-30" y="-30" width="60" height="60" color="#27272a" strokeWidth={1.5} />
          <text x="0" y="90" textAnchor="middle" fill={textColor} fontSize="16" fontWeight="700" style={{fontFamily: 'Oswald'}}>LLM</text>
          <text x="0" y="110" textAnchor="middle" fill={subTextColor} fontSize="11" fontWeight="500" style={{fontFamily: 'JetBrains Mono'}}>GENERATION</text>
        </g>

        {/* --- CONNECTORS (Angular/Orthogonal lines) --- */}
        
        {/* User -> Query Flow */}
        <polyline 
          points="100,220 200,220 200,160"
          fill="none" 
          stroke={currentPart === DiagramPart.EMBEDDING ? "#f97316" : "#27272a"} 
          strokeWidth="2" 
          markerEnd={currentPart === DiagramPart.EMBEDDING ? "url(#arrowhead-active)" : "url(#arrowhead)"}
        />
        
        {/* Embedding -> Vector DB */}
        <polyline 
          points="320,100 430,100" 
          fill="none" 
          stroke={currentPart === DiagramPart.VECTOR_DB ? "#f97316" : "#27272a"} 
          strokeWidth="2" 
          markerEnd={currentPart === DiagramPart.VECTOR_DB ? "url(#arrowhead-active)" : "url(#arrowhead)"}
        />

        {/* Vector DB -> Context */}
        <polyline 
          points="480,140 480,270" 
          fill="none" 
          stroke={currentPart === DiagramPart.RETRIEVAL ? "#f97316" : "#27272a"} 
          strokeWidth="2" 
          strokeDasharray="4 2"
          markerEnd={currentPart === DiagramPart.RETRIEVAL ? "url(#arrowhead-active)" : "url(#arrowhead)"}
        />
        <text x="490" y="210" fill="#52525b" fontSize="10" fontWeight="bold" style={{fontFamily: 'JetBrains Mono'}} transform="rotate(90, 490, 210)">RETRIEVAL</text>

        {/* Query -> Context */}
        <polyline 
          points="100,240 400,240 400,320 410,320" 
          fill="none" 
          stroke={currentPart === DiagramPart.CONTEXT ? "#f97316" : "#27272a"} 
          strokeWidth="2" 
          markerEnd={currentPart === DiagramPart.CONTEXT ? "url(#arrowhead-active)" : "url(#arrowhead)"}
        />

        {/* Context -> LLM */}
        <polyline 
          points="550,320 620,320 620,220" 
          fill="none" 
          stroke={currentPart === DiagramPart.LLM ? "#f97316" : "#27272a"} 
          strokeWidth="2" 
          markerEnd={currentPart === DiagramPart.LLM ? "url(#arrowhead-active)" : "url(#arrowhead)"}
        />

        {/* LLM -> User Response */}
        <polyline 
          points="740,260 740,400 50,400 50,330" 
          fill="none" 
          stroke={currentPart === DiagramPart.RESPONSE ? "#f97316" : "#27272a"} 
          strokeWidth="2" 
          strokeDasharray="4 2"
          markerEnd={currentPart === DiagramPart.RESPONSE ? "url(#arrowhead-active)" : "url(#arrowhead)"}
        />
         <text x="400" y="420" textAnchor="middle" fill={currentPart === DiagramPart.RESPONSE ? "#f97316" : "#27272a"} fontSize="14" fontWeight="bold" style={{fontFamily: 'JetBrains Mono'}}>FINAL ANSWER</text>

      </svg>
      
      {/* Tooltip Area - Industrial Label */}
      <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 w-full text-center">
        {currentPart !== DiagramPart.NONE && (
          <div className="inline-block bg-industrial-surface border-2 border-industrial-border shadow-hard px-6 py-3">
             <div className="text-xs font-mono text-industrial-dim uppercase tracking-wider mb-1 text-left">System Status:</div>
             <div className="text-lg font-bold font-body text-industrial-text">
                {currentPart === DiagramPart.USER && "STEP 0: INPUT_ACQUISITION"}
                {currentPart === DiagramPart.EMBEDDING && "STEP 1: VECTOR_CONVERSION"}
                {currentPart === DiagramPart.VECTOR_DB && "STEP 2: STORAGE_PERSISTENCE"}
                {currentPart === DiagramPart.RETRIEVAL && "STEP 3: SEMANTIC_RETRIEVAL"}
                {currentPart === DiagramPart.CONTEXT && "STEP 3.5: CONTEXT_AUGMENTATION"}
                {currentPart === DiagramPart.LLM && "STEP 4: RESPONSE_GENERATION"}
             </div>
             <div className="text-sm font-mono mt-1 text-orange-600">
                {currentPart === DiagramPart.USER && "ユーザーが質問を入力します。"}
                {currentPart === DiagramPart.EMBEDDING && "テキストを数値（Vector）に変換します。"}
                {currentPart === DiagramPart.VECTOR_DB && "知識データをVectorとして保存します。"}
                {currentPart === DiagramPart.RETRIEVAL && "関連する情報を検索・抽出します。"}
                {currentPart === DiagramPart.CONTEXT && "質問と検索結果を統合します。"}
                {currentPart === DiagramPart.LLM && "Contextに基づき回答を生成します。"}
             </div>
          </div>
        )}
      </div>
    </div>
  );
};