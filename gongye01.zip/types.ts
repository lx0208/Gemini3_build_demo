export interface SlideDef {
  id: string;
  title: string;
  subtitle?: string;
  component: React.ReactNode;
}

export enum DiagramPart {
  NONE = 'none',
  USER = 'user',
  QUERY = 'query',
  EMBEDDING = 'embedding',
  VECTOR_DB = 'vector_db',
  RETRIEVAL = 'retrieval',
  CONTEXT = 'context',
  LLM = 'llm',
  RESPONSE = 'response'
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}