import { GoogleGenAI } from "@google/genai";

// Initialize the client. 
// Note: We create the instance lazily in the function to ensure we capture the key 
// if it changes (though standard env key is static usually).
const getAiClient = () => {
    return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

export const askRagQuestion = async (question: string): Promise<string> => {
  try {
    const ai = getAiClient();
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `You are an expert technical presenter explaining Retrieval-Augmented Generation (RAG) to a Japanese audience.
      
      A user from the audience asks: "${question}"
      
      Answer in Japanese. Keep the tone professional but easy to understand.
      Use English for technical terms (e.g., Vector DB, Embedding, LLM, Hallucination).
      Keep the answer concise (2-3 sentences max) as this is a live presentation demo.`,
    });
    
    return response.text || "申し訳ありません。現在回答を生成できません。";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "申し訳ありません。AIとの接続に問題が発生しました。";
  }
};