import React, { useState, useEffect, useCallback } from 'react';
import { ChevronRight, ChevronLeft, FileText, Database, Search, Cpu, CheckCircle, Settings, Box } from 'lucide-react';
import { RagDiagram } from './components/RagDiagram';
import { DiagramPart, SlideDef } from './types';

// --- Industrial Header Component ---

const GlobalHeader = () => (
  // Seamless header: bg-transparent, but visual separation via border
  <header className="absolute top-0 left-0 w-full h-20 bg-transparent z-50 flex items-center justify-between px-8 border-b-2 border-zinc-800">
    <div className="flex items-center gap-4">
      {/* Logo Area */}
      <div className="w-12 h-12 bg-zinc-900 border-2 border-zinc-900 flex items-center justify-center text-white">
         <Box size={24} strokeWidth={2} />
      </div>
      <div className="flex flex-col">
        <h1 className="text-2xl font-sans font-bold text-zinc-900 tracking-tighter leading-none uppercase">
          JAPAN ZHIMING
        </h1>
        <p className="text-xs font-mono font-bold text-zinc-500 tracking-wider">PRODUCTION TECH DEPT. // 2025</p>
      </div>
    </div>
    
    <div className="hidden md:flex items-center gap-6">
       <div className="flex flex-col items-end">
         <span className="text-[10px] font-mono text-zinc-400">CLASSIFICATION</span>
         <span className="text-sm font-bold font-sans tracking-wide text-zinc-800">INTERNAL ONLY</span>
       </div>
       <div className="w-px h-8 bg-zinc-300"></div>
       <div className="bg-white px-4 py-2 border-2 border-zinc-800 text-zinc-800 font-mono text-sm font-bold shadow-[2px_2px_0px_0px_#27272a]">
          AI_RAG_V1.0
       </div>
    </div>
  </header>
);

// --- Helper Components ---

const SlideWrapper: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div className="w-full h-full flex flex-col items-center justify-center pt-24 p-8 relative animate-fade-in">
    {/* Decorative Corner Marks */}
    <div className="absolute top-24 left-8 w-4 h-4 border-t-2 border-l-2 border-zinc-400" />
    <div className="absolute top-24 right-8 w-4 h-4 border-t-2 border-r-2 border-zinc-400" />
    <div className="absolute bottom-8 left-8 w-4 h-4 border-b-2 border-l-2 border-zinc-400" />
    <div className="absolute bottom-8 right-8 w-4 h-4 border-b-2 border-r-2 border-zinc-400" />
    
    {children}
  </div>
);

const BulletPoint: React.FC<{ children: React.ReactNode; delay?: number }> = ({ children, delay = 0 }) => (
  <div 
    className="flex items-start gap-5 text-xl md:text-2xl text-zinc-700 mb-6 font-body"
    style={{ animation: `slideUp 0.6s ease-out ${delay}ms backwards` }}
  >
    {/* Industrial Screw/Square bullet */}
    <div className="mt-2 w-4 h-4 border-2 border-zinc-800 bg-orange-500 shrink-0 flex items-center justify-center">
       <div className="w-1 h-1 bg-zinc-900 rounded-full"></div>
    </div>
    <div className="leading-snug tracking-wide">{children}</div>
  </div>
);

const SectionTitle: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <h2 className="text-5xl md:text-6xl font-bold font-sans text-zinc-900 mb-10 tracking-tight uppercase border-l-8 border-orange-500 pl-6">
    {children}
  </h2>
);

const CardContainer: React.FC<{ children: React.ReactNode; className?: string }> = ({ children, className = "" }) => (
  <div className={`bg-white border-2 border-zinc-800 shadow-hard ${className}`}>
    {children}
  </div>
);

// --- Main App ---

export default function App() {
  const [currentSlide, setCurrentSlide] = useState(0);

  // --- Slide Definitions ---

  const slides: SlideDef[] = [
    // Slide 0: Title
    {
      id: 'title',
      title: 'AI RAG 技術解説',
      component: (
        <SlideWrapper>
          <div className="text-center w-full max-w-6xl relative">
             {/* Background Big Text */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-[20vw] font-black text-zinc-200 opacity-20 select-none z-0 pointer-events-none font-sans">
              RAG
            </div>

            <div className="relative z-10">
              <div className="inline-block px-4 py-1 mb-6 border border-zinc-400 text-zinc-500 font-mono text-sm tracking-widest bg-zinc-50">
                TECHNICAL BRIEFING
              </div>
              <h1 className="text-7xl md:text-9xl font-black font-sans text-zinc-900 mb-6 tracking-tighter leading-none">
                AI <span className="text-orange-600 bg-clip-text">RAG</span>
              </h1>
              <div className="w-32 h-2 bg-zinc-900 mx-auto mb-10"></div>
              <p className="text-3xl font-body text-zinc-600 max-w-4xl mx-auto font-medium leading-normal mb-16">
                Retrieval-Augmented Generation<br/>
                <span className="text-xl font-mono text-zinc-500 mt-2 block uppercase">検索拡張生成の仕組みと応用</span>
              </p>
              
              <div className="flex justify-center gap-8">
                <CardContainer className="p-6 w-56">
                  <div className="flex flex-col items-center gap-3">
                    <Database size={32} className="text-zinc-800" />
                    <span className="font-mono font-bold text-lg">EXT. DATA</span>
                  </div>
                </CardContainer>
                <div className="flex items-center text-4xl text-zinc-400 font-black">+</div>
                <CardContainer className="p-6 w-56">
                  <div className="flex flex-col items-center gap-3">
                    <Cpu size={32} className="text-zinc-800" />
                    <span className="font-mono font-bold text-lg">CORE LLM</span>
                  </div>
                </CardContainer>
              </div>
            </div>
          </div>
        </SlideWrapper>
      )
    },
    // Slide 1: Agenda / Overview
    {
      id: 'agenda',
      title: 'Workflow Overview',
      component: (
        <SlideWrapper>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 w-full max-w-[1600px] items-center h-full">
            <div className="pl-4">
              <SectionTitle>RAG SYSTEM OVERVIEW</SectionTitle>
              <div className="space-y-6 mt-8">
                 <BulletPoint delay={100}>
                   <span className="font-mono text-zinc-400 mr-4">01.</span>
                   <strong className="text-zinc-900">Indexing (インデックス化)</strong>
                 </BulletPoint>
                 <BulletPoint delay={200}>
                   <span className="font-mono text-zinc-400 mr-4">02.</span>
                   <strong className="text-zinc-900">Retrieval (検索)</strong>
                 </BulletPoint>
                 <BulletPoint delay={300}>
                   <span className="font-mono text-zinc-400 mr-4">03.</span>
                   <strong className="text-zinc-900">Augmentation (拡張)</strong>
                 </BulletPoint>
                 <BulletPoint delay={400}>
                   <span className="font-mono text-zinc-400 mr-4">04.</span>
                   <strong className="text-zinc-900">Generation (生成)</strong>
                 </BulletPoint>
              </div>
              <div className="mt-16 p-6 border-2 border-dashed border-zinc-400 bg-zinc-50 font-mono text-sm text-zinc-600">
                <p className="mb-2 font-bold uppercase text-zinc-400">// Core Concept</p>
                <p className="text-lg text-zinc-800 italic">
                  "LLMの一般的な知識と、組織固有の最新データを繋ぐ架け橋"
                </p>
              </div>
            </div>
            <CardContainer className="h-[550px] w-full p-4 flex items-center justify-center bg-white bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:16px_16px]">
               <RagDiagram activePart={DiagramPart.NONE} />
            </CardContainer>
          </div>
        </SlideWrapper>
      )
    },
    // Slide 2: Step 1 - Indexing
    {
      id: 'step1',
      title: 'Step 1: Indexing',
      component: (
        <SlideWrapper>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 w-full max-w-[1600px] items-center h-full">
            <CardContainer className="order-2 lg:order-1 h-[550px] w-full p-4 flex items-center justify-center bg-white">
               <div className="w-full h-full transform scale-105">
                 <RagDiagram activePart={DiagramPart.VECTOR_DB} />
               </div>
            </CardContainer>
            <div className="order-1 lg:order-2 pl-4">
              <div className="flex items-center gap-4 mb-8">
                 <div className="w-16 h-16 bg-zinc-900 text-white flex items-center justify-center border-2 border-zinc-900 shadow-hard-sm">
                    <FileText size={32}/>
                 </div>
                 <h2 className="text-6xl font-black font-sans text-zinc-900 uppercase">Indexing</h2>
              </div>
              <div className="space-y-6">
                <BulletPoint delay={100}>
                    ドキュメント（PDF, Wiki, 社内DB）を適切なサイズに分割 
                    <span className="block text-sm font-mono text-orange-600 mt-1">&gt;&gt; PROCESS: CHUNKING</span>
                </BulletPoint>
                <BulletPoint delay={200}>
                    <strong>Embedding Model</strong> を使用して、テキストを数値列（Vector）に変換
                </BulletPoint>
                <BulletPoint delay={300}>
                    <strong>Vector Database</strong> に保存し、意味検索が可能な状態にする
                </BulletPoint>
              </div>
            </div>
          </div>
        </SlideWrapper>
      )
    },
    // Slide 3: Step 2 & 3 - Retrieval & Augmentation
    {
      id: 'step2',
      title: 'Step 2 & 3: Retrieval & Augmentation',
      component: (
        <SlideWrapper>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 w-full max-w-[1600px] items-center h-full">
            <div className="pl-4">
              <div className="flex items-center gap-4 mb-8">
                 <div className="w-16 h-16 bg-zinc-900 text-white flex items-center justify-center border-2 border-zinc-900 shadow-hard-sm">
                    <Search size={32}/>
                 </div>
                 <h2 className="text-4xl lg:text-5xl font-black font-sans text-zinc-900 uppercase leading-none">
                    Retrieval &<br/><span className="text-orange-600">Augmentation</span>
                 </h2>
              </div>
              
              <div className="mb-8 relative pl-6 border-l-4 border-zinc-300">
                <h3 className="text-zinc-900 text-2xl font-bold font-sans mb-2 flex items-center gap-3">
                  <span className="font-mono text-zinc-400">02.</span>
                  RETRIEVAL (検索)
                </h3>
                <p className="text-lg text-zinc-700 font-body">ユーザーの質問をVector化し、<strong>Semantic Search</strong> (意味検索) で抽出</p>
              </div>

              <div className="relative pl-6 border-l-4 border-orange-500 bg-orange-50/50 py-2">
                <h3 className="text-zinc-900 text-2xl font-bold font-sans mb-2 flex items-center gap-3">
                  <span className="font-mono text-orange-600">03.</span>
                  AUGMENTATION (拡張)
                </h3>
                <p className="text-lg text-zinc-700 font-body">抽出した情報をPromptに統合し、<strong>Context (文脈)</strong> を構築</p>
              </div>
            </div>
            <CardContainer className="h-[550px] w-full p-4 flex items-center justify-center bg-white">
                <div className="w-full h-full transform scale-105">
                    <RagDiagram activePart={DiagramPart.CONTEXT} />
                </div>
            </CardContainer>
          </div>
        </SlideWrapper>
      )
    },
    // Slide 4: Step 4 - Generation
    {
      id: 'step4',
      title: 'Step 4: Generation',
      component: (
        <SlideWrapper>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 w-full max-w-[1600px] items-center h-full">
            <CardContainer className="order-2 lg:order-1 h-[550px] w-full p-4 flex items-center justify-center bg-white">
               <div className="w-full h-full transform scale-105">
                 <RagDiagram activePart={DiagramPart.LLM} />
               </div>
            </CardContainer>
             <div className="order-1 lg:order-2 pl-4">
              <div className="flex items-center gap-4 mb-8">
                 <div className="w-16 h-16 bg-zinc-900 text-white flex items-center justify-center border-2 border-zinc-900 shadow-hard-sm">
                    <Cpu size={32}/>
                 </div>
                 <h2 className="text-6xl font-black font-sans text-zinc-900 uppercase">Generation</h2>
              </div>
              <div className="space-y-6">
                <BulletPoint delay={100}>
                  LLMへの入力構造:
                  <div className="mt-3 border-2 border-zinc-800 bg-zinc-900 text-zinc-100 p-4 font-mono text-sm shadow-hard-sm">
                    &gt; System_Prompt + Context + Question
                  </div>
                </BulletPoint>
                <BulletPoint delay={200}>提供された <strong>Context</strong> のみに基づいて回答を生成</BulletPoint>
                <BulletPoint delay={300}><strong>Hallucination</strong> (幻覚) を抑制し、正確性を向上</BulletPoint>
              </div>
            </div>
          </div>
        </SlideWrapper>
      )
    },
    // Slide 5: Thank You
    {
      id: 'end',
      title: 'End',
      component: (
        <SlideWrapper>
          <div className="text-center w-full max-w-4xl border-4 border-zinc-900 p-16 bg-white shadow-hard relative overflow-hidden">
             {/* Caution stripes on top and bottom */}
             <div className="absolute top-0 left-0 w-full h-4 bg-stripes border-b-2 border-zinc-900"></div>
             <div className="absolute bottom-0 left-0 w-full h-4 bg-stripes border-t-2 border-zinc-900"></div>

             <div className="inline-flex items-center justify-center w-20 h-20 border-2 border-zinc-900 bg-zinc-100 mb-8 rounded-none">
                <CheckCircle size={48} className="text-zinc-900" />
             </div>
             <h2 className="text-6xl md:text-8xl font-black font-sans text-zinc-900 mb-8 tracking-tighter uppercase">
               THANK YOU
             </h2>
             <p className="text-2xl text-zinc-600 font-bold font-body mb-12">
               ご清聴ありがとうございました
             </p>
             
             <div className="border-t-2 border-zinc-200 pt-8 mt-8 w-full max-w-xl mx-auto">
               <div className="flex items-center justify-center gap-6 text-zinc-500 font-bold font-mono text-sm uppercase tracking-widest">
                 <span>JAPAN ZHIMING</span>
                 <span>//</span>
                 <span>PROD. TECH</span>
                 <span>//</span>
                 <span>2025</span>
               </div>
             </div>
          </div>
        </SlideWrapper>
      )
    }
  ];

  // --- Navigation Logic ---

  const nextSlide = useCallback(() => {
    setCurrentSlide(prev => Math.min(prev + 1, slides.length - 1));
  }, [slides.length]);

  const prevSlide = useCallback(() => {
    setCurrentSlide(prev => Math.max(prev - 1, 0));
  }, []);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight' || e.key === 'Space') nextSlide();
      if (e.key === 'ArrowLeft') prevSlide();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [nextSlide, prevSlide]);

  return (
    <div className="bg-industrial-bg w-screen h-screen relative overflow-hidden text-industrial-text selection:bg-orange-500 selection:text-white">
      
      <GlobalHeader />

      {/* Main Content Area */}
      <main className="relative z-10 w-full h-full">
        {slides[currentSlide].component}
      </main>

      {/* Industrial Controls */}
      <div className="absolute bottom-0 right-0 z-50 flex items-stretch border-t-2 border-l-2 border-zinc-800 bg-white">
        <div className="px-6 py-4 border-r-2 border-zinc-800 flex items-center bg-zinc-50 font-mono font-bold text-xl">
          {String(currentSlide + 1).padStart(2, '0')} / {String(slides.length).padStart(2, '0')}
        </div>
        <button 
          onClick={prevSlide}
          disabled={currentSlide === 0}
          className="px-6 py-4 hover:bg-zinc-200 disabled:opacity-50 disabled:cursor-not-allowed transition-colors border-r-2 border-zinc-800 text-zinc-900"
        >
          <ChevronLeft size={24} strokeWidth={3} />
        </button>
        <button 
          onClick={nextSlide}
          disabled={currentSlide === slides.length - 1}
          className="px-6 py-4 hover:bg-orange-400 bg-orange-500 disabled:bg-zinc-200 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-white disabled:text-zinc-500"
        >
          <ChevronRight size={24} strokeWidth={3} />
        </button>
      </div>

      {/* Progress Bar (Bottom Line) */}
      <div className="absolute bottom-0 left-0 w-full h-2 bg-zinc-300 z-40 border-t border-zinc-800">
        <div 
          className="h-full bg-orange-600 transition-all duration-300 ease-out"
          style={{ width: `${((currentSlide + 1) / slides.length) * 100}%` }}
        />
      </div>

      <style>{`
        @keyframes slideUp {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in {
          animation: slideUp 0.6s cubic-bezier(0.16, 1, 0.3, 1);
        }
      `}</style>
    </div>
  );
}